import Foundation
import CoreImage
import SwiftUI
import UniformTypeIdentifiers

// MARK: - .cube parsing

struct CubeLUT {
    let dimension: Int
    let data: Data   // Float RGBA per entry, red fastest — exactly what CIColorCube expects
}

enum CubeParser {
    static func parse(url: URL) -> CubeLUT? {
        guard let text = try? String(contentsOf: url, encoding: .utf8) else { return nil }
        return parse(text: text)
    }

    static func parse(text: String) -> CubeLUT? {
        var dimension: Int?
        var floats: [Float] = []
        for rawLine in text.components(separatedBy: .newlines) {
            let line = rawLine.trimmingCharacters(in: .whitespaces)
            if line.isEmpty || line.hasPrefix("#") { continue }
            let upper = line.uppercased()
            if upper.hasPrefix("LUT_3D_SIZE") {
                dimension = Int(line.split(separator: " ").last ?? "")
                continue
            }
            if upper.hasPrefix("LUT_1D_SIZE") { return nil }  // compound LUTs not supported
            if upper.hasPrefix("TITLE") || upper.hasPrefix("DOMAIN") { continue }
            let parts = line.split(separator: " ")
            if parts.count == 3,
               let r = Float(parts[0]), let g = Float(parts[1]), let b = Float(parts[2]) {
                floats.append(r); floats.append(g); floats.append(b)
            }
        }
        guard let dim = dimension, dim >= 2, dim <= 64,
              floats.count == dim * dim * dim * 3 else { return nil }
        var rgba: [Float] = []
        rgba.reserveCapacity(dim * dim * dim * 4)
        for i in stride(from: 0, to: floats.count, by: 3) {
            rgba.append(floats[i]); rgba.append(floats[i + 1]); rgba.append(floats[i + 2]); rgba.append(1)
        }
        let data = rgba.withUnsafeBufferPointer { Data(buffer: $0) }
        return CubeLUT(dimension: dim, data: data)
    }
}

/// Parsed-cube cache shared between the UI (main) and the render threads.
final class LUTCubeStore {
    static let shared = LUTCubeStore()
    private var cache: [String: CubeLUT] = [:]
    private let lock = NSLock()

    func cube(for id: String) -> CubeLUT? {
        lock.lock(); defer { lock.unlock() }
        return cache[id]
    }
    func store(_ cube: CubeLUT, for id: String) {
        lock.lock(); cache[id] = cube; lock.unlock()
    }
}

// MARK: - Library

struct LookItem: Identifiable, Equatable {
    enum Source { case builtin, bundled, imported }
    let id: String
    let title: String
    let category: String
    let source: Source
    let fileURL: URL?
}

final class LookLibrary: ObservableObject {
    @Published var selectedID: String = "builtin"
    @Published var items: [LookItem] = []
    @Published var importError: String?

    static let builtinItem = LookItem(id: "builtin", title: "影色", category: "内置", source: .builtin, fileURL: nil)

    private static let categoryLabels: [(key: String, label: String)] = [
        ("gmic-bw", "黑白胶片"),
        ("gmic-colorslide", "反转片"),
        ("gmic-negative_color", "彩色负片"),
        ("gmic-negative_new", "彩负 · 新"),
        ("gmic-negative_old", "彩负 · 老"),
        ("gmic-print", "电影印片"),
        ("gmic-fujixtransiii", "富士模拟"),
        ("gmic-instant_pro", "拍立得 · 专业"),
        ("gmic-instant_consumer", "拍立得 · 生活"),
        ("slay", "原创电影"),
    ]

    init() { reload() }

    var selectedItem: LookItem {
        items.first(where: { $0.id == selectedID }) ?? Self.builtinItem
    }

    func reload() {
        var list: [LookItem] = [Self.builtinItem]
        // Bundled: .cube files copied flat into the app bundle, named "<prefix>__<name>.cube"
        if let urls = Bundle.main.urls(forResourcesWithExtension: "cube", subdirectory: nil) {
            for url in urls.sorted(by: { $0.lastPathComponent < $1.lastPathComponent }) {
                let file = url.lastPathComponent
                guard let sep = file.range(of: "__") else { continue }
                let prefix = String(file[file.startIndex..<sep.lowerBound])
                let label = Self.categoryLabels.first(where: { $0.key == prefix })?.label ?? "内置 LUT"
                let rawName = String(file[sep.upperBound...].dropLast(5))
                list.append(LookItem(id: "bundled:\(file)", title: Self.prettyName(rawName),
                                     category: label, source: .bundled, fileURL: url))
            }
        }
        // Imported: Documents/LUTs
        let dir = Self.importDirectory()
        if let files = try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil) {
            for url in files.filter({ $0.pathExtension.lowercased() == "cube" })
                             .sorted(by: { $0.lastPathComponent < $1.lastPathComponent }) {
                let name = url.deletingPathExtension().lastPathComponent
                list.append(LookItem(id: "imported:\(url.lastPathComponent)", title: name,
                                     category: "我导入的", source: .imported, fileURL: url))
            }
        }
        items = list
        if !list.contains(where: { $0.id == selectedID }) { selectedID = "builtin" }
    }

    func select(_ item: LookItem) {
        if item.source != .builtin, let url = item.fileURL {
            if LUTCubeStore.shared.cube(for: item.id) == nil {
                guard let cube = CubeParser.parse(url: url) else {
                    importError = "「\(item.title)」这个 LUT 文件读不了"
                    return
                }
                LUTCubeStore.shared.store(cube, for: item.id)
            }
        }
        selectedID = item.id
    }

    /// Copies a picked .cube into Documents/LUTs, validates it, and selects it.
    func importLUT(from url: URL) {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        guard url.pathExtension.lowercased() == "cube" else {
            importError = "请选择 .cube 格式的 LUT 文件"
            return
        }
        guard let cube = CubeParser.parse(url: url) else {
            importError = "这个文件不是有效的 3D LUT（.cube），没导进来"
            return
        }
        let dir = Self.importDirectory()
        var dest = dir.appendingPathComponent(url.lastPathComponent)
        var n = 2
        while FileManager.default.fileExists(atPath: dest.path) {
            dest = dir.appendingPathComponent(
                url.deletingPathExtension().lastPathComponent + " \(n)." + url.pathExtension)
            n += 1
        }
        do {
            try FileManager.default.copyItem(at: url, to: dest)
        } catch {
            importError = "复制文件失败，再试一次"
            return
        }
        let item = LookItem(id: "imported:\(dest.lastPathComponent)",
                            title: dest.deletingPathExtension().lastPathComponent,
                            category: "我导入的", source: .imported, fileURL: dest)
        LUTCubeStore.shared.store(cube, for: item.id)
        reload()
        selectedID = item.id
    }

    static func importDirectory() -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent("LUTs", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    static func prettyName(_ raw: String) -> String {
        var name = raw
        if name.hasPrefix("slay-"), let dash = name.dropFirst(5).firstIndex(of: "-") {
            name = String(name.dropFirst(5)[dash...].dropFirst())
        }
        let specials: [String: String] = ["nc": "NC", "vc": "VC", "uc": "UC", "hc": "HC",
                                          "xtrans": "XTrans", "iii": "III", "ii": "II"]
        return name.split(separator: "_").map { word -> String in
            let w = String(word)
            if let s = specials[w.lowercased()] { return s }
            return w.prefix(1).uppercased() + w.dropFirst()
        }.joined(separator: " ")
    }
}

// MARK: - Picker sheet

struct LookPickerView: View {
    @EnvironmentObject var library: LookLibrary
    @Environment(\.dismiss) var dismiss
    @State private var showImporter = false
    @State private var search = ""

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Button {
                        showImporter = true
                    } label: {
                        Label("导入 LUT 文件（.cube）", systemImage: "square.and.arrow.down")
                    }
                }
                ForEach(groupedItems) { group in
                    Section(group.category) {
                        ForEach(group.items) { item in
                            Button {
                                library.select(item)
                                if library.selectedID == item.id { dismiss() }
                            } label: {
                                HStack {
                                    Text(item.title).foregroundStyle(.primary)
                                    Spacer()
                                    if library.selectedID == item.id {
                                        Image(systemName: "checkmark").foregroundStyle(.orange)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("选择调色")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("关闭") { dismiss() }
                }
            }
            .searchable(text: $search, prompt: "搜索 LUT")
            .fileImporter(isPresented: $showImporter,
                          allowedContentTypes: [UTType(filenameExtension: "cube") ?? .data],
                          allowsMultipleSelection: false) { result in
                if case .success(let urls) = result, let url = urls.first {
                    library.importLUT(from: url)
                    if library.importError == nil { dismiss() }
                }
            }
            .alert("导入失败", isPresented: Binding(
                get: { library.importError != nil },
                set: { if !$0 { library.importError = nil } }
            )) {
                Button("好") { library.importError = nil }
            } message: {
                Text(library.importError ?? "")
            }
        }
    }

    private struct LookGroup: Identifiable {
        let category: String
        let items: [LookItem]
        var id: String { category }
    }

    private var groupedItems: [LookGroup] {
        let filtered = search.isEmpty ? library.items
            : library.items.filter { $0.title.localizedCaseInsensitiveContains(search) }
        var order: [String] = []
        var groups: [String: [LookItem]] = [:]
        for item in filtered {
            if groups[item.category] == nil { order.append(item.category) }
            groups[item.category, default: []].append(item)
        }
        return order.map { LookGroup(category: $0, items: groups[$0] ?? []) }
    }
}
