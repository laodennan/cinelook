import SwiftUI
import MetalKit
import CoreImage

/// Live preview: renders the latest camera frame through the look chain, aspect-fill.
///
/// Rendering is pipelined (v0.3.1): each frame is encoded into a command buffer that
/// presents the drawable itself, and at most 3 frames may be in flight. The previous
/// implementation rendered with commandBuffer: nil, which makes CoreImage commit and
/// synchronously wait for the GPU on every frame — that serialization, not pixel
/// count, was the main source of the "操作起来很卡" stutter.
struct PreviewView: UIViewRepresentable {
    let store: FrameStore

    func makeUIView(context: Context) -> MTKView {
        let view = MTKView()
        view.device = MTLCreateSystemDefaultDevice()
        view.framebufferOnly = false
        view.colorPixelFormat = .bgra8Unorm
        view.delegate = context.coordinator
        view.enableSetNeedsDisplay = false
        view.isPaused = false
        view.preferredFramesPerSecond = 30
        view.backgroundColor = .black
        // Cap the render target at the processed-frame size; the display upscales
        // it for free (rendering at the full native drawable was pure waste).
        view.autoResizeDrawable = false
        view.drawableSize = CGSize(width: 960, height: 1280)
        return view
    }

    func updateUIView(_ uiView: MTKView, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(store: store) }

    final class Coordinator: NSObject, MTKViewDelegate {
        let store: FrameStore
        private var ciContext: CIContext?
        private var commandQueue: MTLCommandQueue?
        private let inFlight = DispatchSemaphore(value: 3)

        init(store: FrameStore) { self.store = store }

        func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}

        func draw(in view: MTKView) {
            guard let raw = store.latestRaw,
                  let drawable = view.currentDrawable else { return }
            if ciContext == nil, let device = view.device {
                ciContext = CIContext(mtlDevice: device, options: [.cacheIntermediates: true])
                commandQueue = device.makeCommandQueue()
            }
            guard let ctx = ciContext, let queue = commandQueue,
                  let commandBuffer = queue.makeCommandBuffer() else { return }

            // If the GPU is already 3 frames behind, drop this tick instead of
            // queueing more latency — a viewfinder values freshness over frames.
            guard inFlight.wait(timeout: .now()) == .success else { return }

            let seed = CGFloat(Int.random(in: 0...100_000))
            let processed = LookEngine.shared.apply(to: raw, settings: store.settings,
                                                    grainSeed: seed, forPreview: true)

            let target = CGRect(x: 0, y: 0, width: view.drawableSize.width, height: view.drawableSize.height)
            guard target.width > 0, target.height > 0 else {
                inFlight.signal()
                return
            }
            let scale = max(target.width / processed.extent.width, target.height / processed.extent.height)
            let scaled = processed.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
            let dx = (target.width - scaled.extent.width) / 2 - scaled.extent.minX
            let dy = (target.height - scaled.extent.height) / 2 - scaled.extent.minY
            let finalImage = scaled.transformed(by: CGAffineTransform(translationX: dx, y: dy))

            ctx.render(finalImage, to: drawable.texture, commandBuffer: commandBuffer,
                       bounds: target, colorSpace: CGColorSpace(name: CGColorSpace.sRGB)!)
            commandBuffer.present(drawable)
            let semaphore = inFlight
            commandBuffer.addCompletedHandler { _ in semaphore.signal() }
            commandBuffer.commit()
        }
    }
}
