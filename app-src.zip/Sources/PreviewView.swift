import SwiftUI
import MetalKit
import CoreImage

/// Live preview: renders the latest camera frame through the look chain, aspect-fill.
struct PreviewView: UIViewRepresentable {
    let store: FrameStore

    func makeUIView(context: Context) -> MTKView {
        let view = MTKView()
        view.device = MTLCreateSystemDefaultDevice()
        view.framebufferOnly = false
        view.colorPixelFormat = .bgra8Unorm
        view.delegate = context.coordinator
        view.enableSetNeedsDisplay = false
        view.isPaused = false
        view.preferredFramesPerSecond = 30
        view.backgroundColor = .black
        // Anti-lag (v0.3.0): cap the render target at the processed-frame size.
        // Rendering the filter graph at the full native drawable (~1290x2796) was
        // the main source of preview stutter; the display upscales this for free.
        view.autoResizeDrawable = false
        view.drawableSize = CGSize(width: 1080, height: 1440)
        return view
    }

    func updateUIView(_ uiView: MTKView, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(store: store) }

    final class Coordinator: NSObject, MTKViewDelegate {
        let store: FrameStore
        private var ciContext: CIContext?

        init(store: FrameStore) { self.store = store }

        func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}

        func draw(in view: MTKView) {
            guard let raw = store.latestRaw,
                  let drawable = view.currentDrawable else { return }
            if ciContext == nil, let device = view.device {
                // cacheIntermediates on (v0.3.0): the look chain shares subgraphs
                // (grade feeds halation and grain); caching them smooths the preview.
                ciContext = CIContext(mtlDevice: device, options: [.cacheIntermediates: true])
            }
            guard let ctx = ciContext else { return }

            let seed = CGFloat(Int.random(in: 0...100_000))
            let processed = LookEngine.shared.apply(to: raw, settings: store.settings, grainSeed: seed)

            let target = CGRect(x: 0, y: 0, width: view.drawableSize.width, height: view.drawableSize.height)
            guard target.width > 0, target.height > 0 else { return }
            let scale = max(target.width / processed.extent.width, target.height / processed.extent.height)
            let scaled = processed.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
            let dx = (target.width - scaled.extent.width) / 2 - scaled.extent.minX
            let dy = (target.height - scaled.extent.height) / 2 - scaled.extent.minY
            let finalImage = scaled.transformed(by: CGAffineTransform(translationX: dx, y: dy))

            ctx.render(finalImage, to: drawable.texture, commandBuffer: nil,
                       bounds: target, colorSpace: CGColorSpace(name: CGColorSpace.sRGB)!)
            drawable.present()
        }
    }
}
