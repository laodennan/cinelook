import UIKit
import CoreImage
import Foundation

/// The single orientation authority for stills (v0.5.0 rewrite).
///
/// Photo data arrives as sensor pixels plus an EXIF orientation tag. The
/// v0.4.x pipeline trusted that tag through a chain of transforms (capture
/// connection rotation, CIImage.oriented, a UIKit burn-in that round-tripped
/// through CIImage) and the steps disagreed by 180° — saved photos came out
/// upside down, then the watermark did. This helper ends the argument: the
/// orientation is baked into the pixels ONCE, here, using UIKit's standard
/// orientation handling. Everything downstream works on provably upright
/// pixels whose orientation is 1 by construction, and no other code in the
/// app touches orientation at all.
enum StillImage {
    /// Decode captured photo data (or any still file data) into an upright CIImage.
    static func uprightCIImage(fromPhotoData data: Data) -> CIImage? {
        guard let ui = UIImage(data: data) else { return nil }
        let baked = bakeOrientation(ui)
        TraceLog.mark("still: baked \(Int(baked.size.width))x\(Int(baked.size.height)), source orientation \(ui.imageOrientation.rawValue)")
        guard let cg = baked.cgImage else { return nil }
        return CIImage(cgImage: cg)
    }

    /// Redraws the image at its orientation-aware size so the result has
    /// orientation .up and physically upright pixels (mirroring included,
    /// which keeps front-camera selfies matching the preview).
    static func bakeOrientation(_ ui: UIImage) -> UIImage {
        if ui.imageOrientation == .up { return ui }
        let format = UIGraphicsImageRendererFormat.default()
        format.scale = 1
        return UIGraphicsImageRenderer(size: ui.size, format: format).image { _ in
            ui.draw(at: .zero)
        }
    }
}
