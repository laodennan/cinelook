import SwiftUI
import CoreImage
import CoreLocation
import UIKit

// MARK: - Settings (persisted in UserDefaults)

enum WMPosition: String, CaseIterable, Identifiable {
    case topLeft, topRight, bottomLeft, bottomRight
    var id: String { rawValue }
    var label: String {
        switch self {
        case .topLeft: return "左上"
        case .topRight: return "右上"
        case .bottomLeft: return "左下"
        case .bottomRight: return "右下"
        }
    }
}

final class WatermarkStore: ObservableObject {
    static let shared = WatermarkStore()
    private let defaults = UserDefaults.standard

    @Published var enabled: Bool { didSet { defaults.set(enabled, forKey: "wm.enabled") } }
    @Published var showModel: Bool { didSet { defaults.set(showModel, forKey: "wm.model") } }
    @Published var showParams: Bool { didSet { defaults.set(showParams, forKey: "wm.params") } }
    @Published var showDate: Bool { didSet { defaults.set(showDate, forKey: "wm.date") } }
    @Published var showLocation: Bool { didSet { defaults.set(showLocation, forKey: "wm.location") } }
    @Published var showWeather: Bool { didSet { defaults.set(showWeather, forKey: "wm.weather") } }
    @Published var position: WMPosition { didSet { defaults.set(position.rawValue, forKey: "wm.position") } }

    init() {
        enabled = defaults.bool(forKey: "wm.enabled")
        showModel = defaults.object(forKey: "wm.model") as? Bool ?? true
        showParams = defaults.object(forKey: "wm.params") as? Bool ?? true
        showDate = defaults.object(forKey: "wm.date") as? Bool ?? true
        showLocation = defaults.bool(forKey: "wm.location")
        showWeather = defaults.bool(forKey: "wm.weather")
        position = WMPosition(rawValue: defaults.string(forKey: "wm.position") ?? "") ?? .bottomLeft
    }
}

// MARK: - Content assembly (model / date / location / weather / params)

enum WatermarkService {
    static func modelName() -> String {
        var info = utsname()
        uname(&info)
        let machine = withUnsafePointer(to: &info.machine) {
            $0.withMemoryRebound(to: CChar.self, capacity: 1) { String(validatingUTF8: $0) ?? "" }
        }
        let table: [String: String] = [
            "iPhone17,2": "iPhone 16 Pro Max", "iPhone17,1": "iPhone 16 Pro",
            "iPhone17,3": "iPhone 16", "iPhone17,4": "iPhone 16 Plus", "iPhone17,5": "iPhone 16e",
            "iPhone16,2": "iPhone 15 Pro Max", "iPhone16,1": "iPhone 15 Pro",
            "iPhone15,5": "iPhone 15", "iPhone15,4": "iPhone 15 Plus",
            "iPhone18,2": "iPhone 17 Pro Max", "iPhone18,1": "iPhone 17 Pro", "iPhone18,3": "iPhone 17",
        ]
        return table[machine] ?? "iPhone"
    }

    /// Lines for a fresh capture, in display order. Location and weather are
    /// best-effort with short timeouts — a missing line is silently omitted.
    static func assembleLines(store: WatermarkStore, params: String, date: Date = Date()) async -> [String] {
        var lines: [String] = []
        var head: [String] = []
        if store.showModel { head.append(modelName()) }
        if store.showParams && !params.isEmpty { head.append(params) }
        if !head.isEmpty { lines.append(head.joined(separator: " · ")) }

        if store.showDate {
            let f = DateFormatter()
            f.locale = Locale(identifier: "zh_CN")
            f.dateFormat = "yyyy年M月d日 HH:mm"
            lines.append(f.string(from: date))
        }

        if store.showLocation || store.showWeather {
            var tail: [String] = []
            if let place = await LocationFetcher.oneShot() {
                if store.showLocation, let name = place.name, !name.isEmpty { tail.append(name) }
                if store.showWeather, let w = await weather(lat: place.coord.latitude, lon: place.coord.longitude) {
                    tail.append(w)
                }
            }
            if !tail.isEmpty { lines.append(tail.joined(separator: " · ")) }
        }
        return lines
    }

    // Weather: Open-Meteo (free, no key). Cached for 20 minutes.
    private static var weatherCache: (text: String, at: Date)?
    private static func weather(lat: Double, lon: Double) async -> String? {
        if let c = weatherCache, Date().timeIntervalSince(c.at) < 1200 { return c.text }
        var comps = URLComponents(string: "https://api.open-meteo.com/v1/forecast")
        comps?.queryItems = [
            URLQueryItem(name: "latitude", value: String(format: "%.4f", lat)),
            URLQueryItem(name: "longitude", value: String(format: "%.4f", lon)),
            URLQueryItem(name: "current", value: "temperature_2m,weather_code"),
        ]
        guard let url = comps?.url else { return nil }
        var req = URLRequest(url: url)
        req.timeoutInterval = 3
        guard let (data, _) = try? await URLSession.shared.data(for: req),
              let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let current = root["current"] as? [String: Any],
              let temp = current["temperature_2m"] as? Double,
              let code = current["weather_code"] as? Int else { return nil }
        let text = "\(weatherText(code)) \(Int(temp.rounded()))°C"
        weatherCache = (text, Date())
        return text
    }

    private static func weatherText(_ code: Int) -> String {
        switch code {
        case 0: return "晴"
        case 1, 2: return "多云"
        case 3: return "阴"
        case 45, 48: return "雾"
        case 51, 53, 55: return "毛毛雨"
        case 61: return "小雨"
        case 63: return "中雨"
        case 65: return "大雨"
        case 71: return "小雪"
        case 73: return "中雪"
        case 75, 77: return "大雪"
        case 80: return "小阵雨"
        case 81: return "阵雨"
        case 82: return "暴雨"
        case 85, 86: return "阵雪"
        case 95: return "雷阵雨"
        case 96, 99: return "冰雹雷雨"
        default: return ""
        }
    }
}

/// One-shot location + placename. Returns nil when unauthorized or timed out;
/// when permission was never asked, this triggers the system prompt (the line
/// will simply appear from the next shot on).
final class LocationFetcher: NSObject, CLLocationManagerDelegate {
    private let manager = CLLocationManager()
    private var continuation: CheckedContinuation<(coord: CLLocationCoordinate2D, name: String?)?, Never>?
    private var finished = false

    static func oneShot() async -> (coord: CLLocationCoordinate2D, name: String?)? {
        let fetcher = LocationFetcher()
        return await withCheckedContinuation { cont in
            fetcher.continuation = cont
            fetcher.start()
        }
    }

    private func start() {
        manager.delegate = self
        switch manager.authorizationStatus {
        case .notDetermined:
            manager.requestWhenInUseAuthorization()
            finish(nil)   // this shot omits the line; the prompt is now shown
        case .authorizedWhenInUse, .authorizedAlways:
            manager.requestLocation()
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [weak self] in
                self?.finish(nil)
            }
        default:
            finish(nil)
        }
    }

    private func finish(_ value: (coord: CLLocationCoordinate2D, name: String?)?) {
        guard !finished else { return }
        finished = true
        continuation?.resume(returning: value)
        continuation = nil
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let loc = locations.last else { finish(nil); return }
        let coord = loc.coordinate
        CLGeocoder().reverseGeocodeLocation(loc) { [weak self] placemarks, _ in
            var name: String?
            if let p = placemarks?.first {
                var parts: [String] = []
                for part in [p.administrativeArea, p.locality, p.subLocality] {
                    if let part, !part.isEmpty, !parts.contains(part) { parts.append(part) }
                }
                name = parts.joined()
            }
            self?.finish((coord, name))
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        finish(nil)
    }
}

// MARK: - Burn-in

enum Watermark {
    /// Draws the lines over the rendered pixels (dark translucent backing,
    /// white text), placed in the chosen corner. Returns nil on render failure.
    static func burn(lines: [String], position: WMPosition, into image: CIImage, context: CIContext) -> CIImage? {
        guard !lines.isEmpty,
              let cg = context.createCGImage(image, from: image.extent) else { return nil }
        let size = CGSize(width: cg.width, height: cg.height)
        let fontSize = max(20, min(64, size.width * 0.027))
        let font = UIFont.systemFont(ofSize: fontSize, weight: .medium)
        let lineHeight = fontSize * 1.32
        let padX = fontSize * 0.75
        let padY = fontSize * 0.5
        let textAttrs: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: UIColor.white]
        var textWidth: CGFloat = 0
        for line in lines {
            textWidth = max(textWidth, (line as NSString).size(withAttributes: textAttrs).width)
        }
        let blockW = textWidth + padX * 2
        let blockH = lineHeight * CGFloat(lines.count) + padY * 2
        let margin = size.width * 0.03
        let rightAligned = (position == .topRight || position == .bottomRight)
        let blockX = rightAligned ? size.width - margin - blockW : margin
        // UIKit drawing origin is top-left; CIImage pixels are already upright here.
        let blockY: CGFloat
        switch position {
        case .topLeft, .topRight: blockY = margin
        case .bottomLeft, .bottomRight: blockY = size.height - margin - blockH
        }
        let renderer = UIGraphicsImageRenderer(size: size)
        let out = renderer.image { ctx in
            ctx.cgContext.draw(cg, in: CGRect(origin: .zero, size: size))
            let rect = CGRect(x: blockX, y: blockY, width: blockW, height: blockH)
            let path = UIBezierPath(roundedRect: rect, cornerRadius: fontSize * 0.35)
            UIColor.black.withAlphaComponent(0.38).setFill()
            path.fill()
            for (i, line) in lines.enumerated() {
                let w = (line as NSString).size(withAttributes: textAttrs).width
                let x = rightAligned ? rect.maxX - padX - w : rect.minX + padX
                let y = rect.minY + padY + CGFloat(i) * lineHeight
                (line as NSString).draw(at: CGPoint(x: x, y: y), withAttributes: textAttrs)
            }
        }
        guard let outCG = out.cgImage else { return nil }
        return CIImage(cgImage: outCG)
    }
}

// MARK: - Settings UI

struct WatermarkSettingsView: View {
    @ObservedObject private var store = WatermarkStore.shared
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("显示内容") {
                    Toggle("手机型号", isOn: $store.showModel)
                    Toggle("拍摄参数（焦段 / ISO / 快门）", isOn: $store.showParams)
                    Toggle("日期时间", isOn: $store.showDate)
                    Toggle("位置（地名）", isOn: $store.showLocation)
                    Toggle("天气（需定位，联网获取）", isOn: $store.showWeather)
                }
                Section("水印位置") {
                    Picker("位置", selection: $store.position) {
                        ForEach(WMPosition.allCases) { p in
                            Text(p.label).tag(p)
                        }
                    }
                    .pickerStyle(.segmented)
                }
                Section {
                    Text("水印只印在保存到相册的照片上，取景预览里不显示。第一次打开「位置」时系统会问你要定位权限，允许之后从下一张开始带地名。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("水印设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
    }
}
