import Foundation

/// Tiny step-by-step trace written to Documents/trace.log.
/// Purpose: if the shutter flow ever dies mid-way, the last line in the file
/// names the step that was running — evidence instead of guesswork.
enum TraceLog {
    private static let queue = DispatchQueue(label: "lumacam.trace")

    static var fileURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("trace.log")
    }

    static func mark(_ step: String) {
        let line = "\(Date())  \(step)\n"
        queue.async {
            let url = fileURL
            if let handle = try? FileHandle(forWritingTo: url) {
                handle.seekToEndOfFile()
                if let data = line.data(using: .utf8) { handle.write(data) }
                try? handle.close()
            } else {
                try? line.write(to: url, atomically: true, encoding: .utf8)
            }
        }
    }

    static func reset() {
        queue.async { try? FileManager.default.removeItem(at: fileURL) }
    }
}
