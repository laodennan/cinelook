import CoreImage
import Foundation
import ImageIO

/// The one "look" of this camera: cinematic color, deep shadows, cream highlights,
/// plus film grain and red halation around bright lights.
struct LookSettings: Equatable {
    var intensity: Double = 1.0   // 0 = original, 1 = full look
    var grain: Int = 1            // 0 = off, 1 = fine, 2 = coarse
    var halation: Bool = true
    var monochrome: Bool = false
}

final class LookEngine {
    static let shared = LookEngine()

    /// Shared context for still renders / thumbnails (preview uses its own Metal context).
    let context = CIContext(options: [.cacheIntermediates: false])

    private var cubeData: Data?
    private let cubeDimension = 32

    // MARK: - Filter helper (classic CIFilter API, battle-tested)

    private func makeFilter(_ name: String, _ params: [String: Any]) -> CIFilter? {
        guard let f = CIFilter(name: name) else { return nil }
        for (k, v) in params { f.setValue(v, forKey: k) }
        return f
    }

    // MARK: - The color grade, baked into a 3D LUT

    private func smoothstep(_ x: Float) -> Float { x * x * (3 - 2 * x) }

    private func gradeChannel(_ r0: Float, _ g0: Float, _ b0: Float) -> (Float, Float, Float) {
        var r = r0, g = g0, b = b0
        // 1) gentle desaturation toward luma
        let luma = 0.2126 * r + 0.7152 * g + 0.0722 * b
        let desat: Float = 0.10
        r += (luma - r) * desat
        g += (luma - g) * desat
        b += (luma - b) * desat
        // 2) mild filmic S-curve (soft highlight rolloff, firm shadows)
        let curveAmt: Float = 0.24
        r = r * (1 - curveAmt) + smoothstep(r) * curveAmt
        g = g * (1 - curveAmt) + smoothstep(g) * curveAmt
        b = b * (1 - curveAmt) + smoothstep(b) * curveAmt
        // 3) split tone: cool teal shadows, warm cream highlights
        let l2 = 0.2126 * r + 0.7152 * g + 0.0722 * b
        let sh = (1 - l2) * (1 - l2)   // shadow weight
        let hi = l2 * l2               // highlight weight
        r += -0.012 * sh + 0.045 * hi
        g +=  0.014 * sh + 0.028 * hi
        b +=  0.038 * sh - 0.012 * hi
        // 4) deep (not crushed) blacks: tiny lift, slight overall pull-down
        r = r * 0.97 + 0.012
        g = g * 0.97 + 0.012
        b = b * 0.97 + 0.012
        return (min(max(r, 0), 1), min(max(g, 0), 1), min(max(b, 0), 1))
    }

    private func lutData() -> Data {
        if let cubeData { return cubeData }
        let dim = cubeDimension
        var floats = [Float]()
        floats.reserveCapacity(dim * dim * dim * 4)
        for b in 0..<dim {
            for g in 0..<dim {
                for r in 0..<dim {
                    let (rr, gg, bb) = gradeChannel(Float(r) / Float(dim - 1),
                                                    Float(g) / Float(dim - 1),
                                                    Float(b) / Float(dim - 1))
                    floats.append(rr); floats.append(gg); floats.append(bb); floats.append(1)
                }
            }
        }
        let data = floats.withUnsafeBufferPointer { Data(buffer: $0) }
        cubeData = data
        return data
    }

    // MARK: - Halation: red glow around the brightest parts

    private func addHalation(to base: CIImage, extent: CGRect) -> CIImage {
        // Colored highlight layer: value = (L - 0.72) * gain, tinted warm red.
        let gain: Float = 3.0 * 0.55
        let lr = 0.2126 * gain, lg = 0.7152 * gain, lb = 0.0722 * gain
        let bias = -0.72 * gain
        guard let matrix = makeFilter("CIColorMatrix", [
            kCIInputImageKey: base.clampedToExtent(),
            "inputRVector": CIVector(x: CGFloat(lr), y: CGFloat(lg), z: CGFloat(lb), w: 0),
            "inputGVector": CIVector(x: CGFloat(lr * 0.22), y: CGFloat(lg * 0.22), z: CGFloat(lb * 0.22), w: 0),
            "inputBVector": CIVector(x: CGFloat(lr * 0.08), y: CGFloat(lg * 0.08), z: CGFloat(lb * 0.08), w: 0),
            "inputAVector": CIVector(x: 0, y: 0, z: 0, w: 0),
            "inputBiasVector": CIVector(x: CGFloat(bias), y: CGFloat(bias * 0.22), z: CGFloat(bias * 0.08), w: 0),
        ]), var layer = matrix.outputImage else { return base }

        let radius = max(extent.width, extent.height) * 0.02
        if let blur = makeFilter("CIGaussianBlur", [
            kCIInputImageKey: layer.clampedToExtent(),
            kCIInputRadiusKey: radius,
        ]), let blurred = blur.outputImage {
            layer = blurred
        }
        guard let screen = makeFilter("CIScreenBlendMode", [
            kCIInputImageKey: layer.cropped(to: extent),
            kCIInputBackgroundImageKey: base,
        ]), let out = screen.outputImage else { return base }
        return out
    }

    // MARK: - Film grain

    private func addGrain(to base: CIImage, extent: CGRect, level: Int, seed: CGFloat) -> CIImage {
        guard let noise = CIFilter(name: "CIRandomGenerator")?.outputImage else { return base }
        let shiftX = (seed.truncatingRemainder(dividingBy: 977))
        let shiftY = (seed.truncatingRemainder(dividingBy: 631)) * 1.7
        var n = noise.transformed(by: CGAffineTransform(translationX: -shiftX, y: -shiftY))
        if level == 2 {
            // coarser grain: soften the fine noise so clumps read bigger
            if let blur = makeFilter("CIGaussianBlur", [
                kCIInputImageKey: n.clampedToExtent(),
                kCIInputRadiusKey: 1.3,
            ]), let b = blur.outputImage { n = b }
        }
        n = n.cropped(to: extent)
        // map noise to a soft-light layer centered on 0.5 gray
        let depth: CGFloat = level == 2 ? 0.13 : 0.075
        guard let mat = makeFilter("CIColorMatrix", [
            kCIInputImageKey: n,
            "inputRVector": CIVector(x: depth, y: depth, z: depth, w: 0),
            "inputGVector": CIVector(x: depth, y: depth, z: depth, w: 0),
            "inputBVector": CIVector(x: depth, y: depth, z: depth, w: 0),
            "inputAVector": CIVector(x: 0, y: 0, z: 0, w: 0),
            "inputBiasVector": CIVector(x: 0.5 - depth / 2, y: 0.5 - depth / 2, z: 0.5 - depth / 2, w: 0),
        ]), let grainLayer = mat.outputImage,
              let soft = makeFilter("CISoftLightBlendMode", [
            kCIInputImageKey: grainLayer,
            kCIInputBackgroundImageKey: base,
        ]), let out = soft.outputImage else { return base }
        return out
    }

    // MARK: - Full chain

    func apply(to image: CIImage, settings: LookSettings, grainSeed: CGFloat = 0) -> CIImage {
        let extent = image.extent
        guard extent.width > 0, extent.height > 0 else { return image }

        var graded = image
        if let cube = makeFilter("CIColorCube", [
            kCIInputImageKey: image,
            "inputCubeDimension": cubeDimension,
            "inputCubeData": lutData(),
        ]), let out = cube.outputImage {
            graded = out
        }

        if settings.monochrome,
           let cc = makeFilter("CIColorControls", [
               kCIInputImageKey: graded,
               kCIInputSaturationKey: 0.0,
               kCIInputContrastKey: 1.05,
           ]), let out = cc.outputImage {
            graded = out
        }

        if settings.halation && !settings.monochrome {
            graded = addHalation(to: graded, extent: extent)
        }

        if settings.grain > 0 {
            graded = addGrain(to: graded, extent: extent, level: settings.grain, seed: grainSeed)
        }

        if settings.intensity < 0.999 {
            let mask = CIImage(color: CIColor(red: 1, green: 1, blue: 1, alpha: CGFloat(settings.intensity)))
                .cropped(to: extent)
            if let blend = makeFilter("CIBlendWithAlphaMask", [
                kCIInputImageKey: graded,
                kCIInputBackgroundImageKey: image,
                kCIInputMaskImageKey: mask,
            ]), let out = blend.outputImage {
                graded = out
            }
        }
        return graded.cropped(to: extent)
    }
}

/// Fix orientation of a CIImage loaded from file data using its EXIF orientation.
func orientedFromEXIF(_ image: CIImage) -> CIImage {
    if let o = image.properties[kCGImagePropertyOrientation as String] as? Int32, o != 1 {
        return image.oriented(forExifOrientation: o)
    }
    return image
}
