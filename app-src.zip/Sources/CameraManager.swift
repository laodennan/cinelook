import AVFoundation
import CoreImage
import Foundation

/// Shared mutable frame + settings store between the camera, the settings UI and the preview renderer.
final class FrameStore {
    var latestRaw: CIImage?
    var settings = LookSettings()
}

enum Lens: String, CaseIterable {
    case ultraWide, wide, tele

    var deviceType: AVCaptureDevice.DeviceType {
        switch self {
        case .ultraWide: return .builtInUltraWideCamera
        case .wide: return .builtInWideAngleCamera
        case .tele: return .builtInTelephotoCamera
        }
    }
    var label: String {
        switch self {
        case .ultraWide: return "0.5×"
        case .wide: return "1×"
        case .tele: return "5×"
        }
    }
}

final class CameraManager: NSObject, ObservableObject {
    @Published var statusMessage: String = "正在准备相机…"
    @Published var availableLenses: [Lens] = [.wide]
    @Published var currentLens: Lens = .wide

    let store = FrameStore()

    private let session = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private let photoOutput = AVCapturePhotoOutput()
    private let sessionQueue = DispatchQueue(label: "lumacam.session")
    private var photoHandler: ((Data?) -> Void)?
    private var controlsDelegate: NSObject?

    func start() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            configureAndRun()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                if granted {
                    self?.configureAndRun()
                } else {
                    self?.setStatus("没有相机权限，请到系统「设置 → LumaCam」里打开")
                }
            }
        default:
            setStatus("没有相机权限，请到系统「设置 → LumaCam」里打开")
        }
    }

    private func setStatus(_ s: String) {
        DispatchQueue.main.async { [weak self] in self?.statusMessage = s }
    }

    private func configureAndRun() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.session.inputs.isEmpty {
                // Camera Control support (iPhone 16 series hardware button): expose the
                // look intensity as a capture control the button's swipe can adjust.
                if #available(iOS 18.0, *), self.session.supportsControls {
                    let delegate = ControlsDelegate()
                    self.controlsDelegate = delegate
                    self.session.setControlsDelegate(delegate, queue: self.sessionQueue)
                }

                self.session.beginConfiguration()
                self.session.sessionPreset = .photo
                guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
                      let input = try? AVCaptureDeviceInput(device: device),
                      self.session.canAddInput(input) else {
                    self.session.commitConfiguration()
                    self.setStatus("找不到可用的相机")
                    return
                }
                self.session.addInput(input)

                self.videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
                self.videoOutput.alwaysDiscardsLateVideoFrames = true
                if self.session.canAddOutput(self.videoOutput) {
                    self.session.addOutput(self.videoOutput)
                    self.videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "lumacam.video"))
                    if let conn = self.videoOutput.connection(with: .video),
                       conn.isVideoRotationAngleSupported(90) {
                        conn.videoRotationAngle = 90
                    }
                }
                if self.session.canAddOutput(self.photoOutput) {
                    self.session.addOutput(self.photoOutput)
                }

                if #available(iOS 18.0, *), self.session.supportsControls {
                    let slider = AVCaptureSlider("调色强度", symbolName: "circle.lefthalf.filled",
                                                 in: 0.0...1.0)
                    slider.value = Float(self.store.settings.intensity)
                    let store = self.store
                    slider.setActionQueue(self.sessionQueue) { value in
                        store.settings.intensity = Double(value)
                    }
                    if self.session.canAddControl(slider) {
                        self.session.addControl(slider)
                    }
                }
                self.session.commitConfiguration()

                let lenses = Lens.allCases.filter {
                    AVCaptureDevice.default($0.deviceType, for: .video, position: .back) != nil
                }
                DispatchQueue.main.async { [weak self] in self?.availableLenses = lenses }
            }
            if !self.session.isRunning { self.session.startRunning() }
            self.setStatus("")
        }
    }

    func switchLens(_ lens: Lens) {
        guard lens != currentLens else { return }
        sessionQueue.async { [weak self] in
            guard let self,
                  let device = AVCaptureDevice.default(lens.deviceType, for: .video, position: .back),
                  let newInput = try? AVCaptureDeviceInput(device: device) else { return }
            self.session.beginConfiguration()
            let oldInput = self.session.inputs.compactMap { $0 as? AVCaptureDeviceInput }.first
            if let oldInput { self.session.removeInput(oldInput) }
            if self.session.canAddInput(newInput) {
                self.session.addInput(newInput)
            } else if let oldInput, self.session.canAddInput(oldInput) {
                self.session.addInput(oldInput)
                self.session.commitConfiguration()
                return
            }
            self.session.commitConfiguration()
            if let conn = self.videoOutput.connection(with: .video),
               conn.isVideoRotationAngleSupported(90) {
                conn.videoRotationAngle = 90
            }
            DispatchQueue.main.async { [weak self] in self?.currentLens = lens }
        }
    }

    func capturePhoto(handler: @escaping (Data?) -> Void) {
        sessionQueue.async { [weak self] in
            guard let self else { handler(nil); return }
            self.photoHandler = handler
            if let conn = self.photoOutput.connection(with: .video),
               conn.isVideoRotationAngleSupported(90) {
                conn.videoRotationAngle = 90
            }
            let settings: AVCapturePhotoSettings
            if self.photoOutput.availablePhotoCodecTypes.contains(.hevc) {
                settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.hevc])
            } else {
                settings = AVCapturePhotoSettings()
            }
            settings.photoQualityPrioritization = .quality
            self.photoOutput.capturePhoto(with: settings, delegate: self)
        }
    }
}

@available(iOS 18.0, *)
final class ControlsDelegate: NSObject, AVCaptureSessionControlsDelegate {
    func sessionControlsDidBecomeActive(_ session: AVCaptureSession) {}
    func sessionControlsDidBecomeInactive(_ session: AVCaptureSession) {}
    func sessionControlsWillEnterFullscreen(_ session: AVCaptureSession) {}
    func sessionControlsDidEnterFullscreen(_ session: AVCaptureSession) {}
}

extension CameraManager: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pb = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        let img = CIImage(cvPixelBuffer: pb)
        // Preview works on a downscaled copy so the filter chain stays cheap;
        // the photo output still captures at full sensor resolution.
        let maxSide: CGFloat = 1440
        let m = max(img.extent.width, img.extent.height)
        if m > maxSide {
            store.latestRaw = img.transformed(by: CGAffineTransform(scaleX: maxSide / m, y: maxSide / m))
        } else {
            store.latestRaw = img
        }
    }
}

extension CameraManager: AVCapturePhotoCaptureDelegate {
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        let data = error == nil ? photo.fileDataRepresentation() : nil
        let handler = photoHandler
        photoHandler = nil
        DispatchQueue.main.async { handler?(data) }
    }
}
