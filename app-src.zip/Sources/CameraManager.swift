import AVFoundation
import CoreImage
import Foundation

/// Shared mutable frame + settings store between the camera, the settings UI and the preview renderer.
final class FrameStore {
    var latestRaw: CIImage?
    var settings = LookSettings()
}

enum Lens: String, CaseIterable {
    case ultraWide, wide, tele

    var deviceType: AVCaptureDevice.DeviceType {
        switch self {
        case .ultraWide: return .builtInUltraWideCamera
        case .wide: return .builtInWideAngleCamera
        case .tele: return .builtInTelephotoCamera
        }
    }
}

/// Focal lengths as shown in the UI, the way pro camera apps label them (mm).
enum Focal: String, CaseIterable {
    case f13, f24, f48, f120

    var mm: String {
        switch self {
        case .f13: return "13"
        case .f24: return "24"
        case .f48: return "48"
        case .f120: return "120"
        }
    }
    var lens: Lens {
        switch self {
        case .f13: return .ultraWide
        case .f24, .f48: return .wide
        case .f120: return .tele
        }
    }
    /// 48mm is the main camera's 2x centre crop, not a separate lens.
    var zoom: CGFloat { self == .f48 ? 2.0 : 1.0 }
}

/// Manual exposure / focus / white-balance state (the five pro controls).
struct ManualState: Equatable {
    var focusAuto = true
    var focusValue: Float = 0.5          // lens position 0 (near) … 1 (far)
    var wbAuto = true
    var wbKelvin: Float = 5200
    var shutterAuto = true
    var shutterSeconds: Double = 1.0 / 125.0
    var isoAuto = true
    var isoValue: Float = 100
    var evValue: Float = 0
    var isoMin: Float = 50
    var isoMax: Float = 1600
}

final class CameraManager: NSObject, ObservableObject {
    @Published var statusMessage: String = "正在准备相机…"
    @Published var availableFocals: [Focal] = [.f24, .f48]
    @Published var currentFocal: Focal = .f24
    @Published var isFront = false
    @Published var manual = ManualState()

    let store = FrameStore()

    private let session = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private let photoOutput = AVCapturePhotoOutput()
    private let sessionQueue = DispatchQueue(label: "lumacam.session")
    private var photoHandler: ((Data?) -> Void)?
    private var controlsDelegate: NSObject?
    private var position: AVCaptureDevice.Position = .back
    private var currentLens: Lens = .wide

    private var currentDevice: AVCaptureDevice? {
        (session.inputs.first as? AVCaptureDeviceInput)?.device
    }

    func start() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            configureAndRun()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                if granted {
                    self?.configureAndRun()
                } else {
                    self?.setStatus("没有相机权限，请到系统「设置 → LumaCam」里打开")
                }
            }
        default:
            setStatus("没有相机权限，请到系统「设置 → LumaCam」里打开")
        }
    }

    private func setStatus(_ s: String) {
        DispatchQueue.main.async { [weak self] in self?.statusMessage = s }
    }

    private func configureAndRun() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.session.inputs.isEmpty {
                // Camera Control support (iPhone 16 series hardware button): expose the
                // look intensity as a capture control the button's swipe can adjust.
                if #available(iOS 18.0, *), self.session.supportsControls {
                    let delegate = ControlsDelegate()
                    self.controlsDelegate = delegate
                    self.session.setControlsDelegate(delegate, queue: self.sessionQueue)
                }

                self.session.beginConfiguration()
                self.session.sessionPreset = .photo
                guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
                      let input = try? AVCaptureDeviceInput(device: device),
                      self.session.canAddInput(input) else {
                    self.session.commitConfiguration()
                    self.setStatus("找不到可用的相机")
                    return
                }
                self.session.addInput(input)

                self.videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
                self.videoOutput.alwaysDiscardsLateVideoFrames = true
                if self.session.canAddOutput(self.videoOutput) {
                    self.session.addOutput(self.videoOutput)
                    self.videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "lumacam.video"))
                    self.configureConnections(front: false)
                }
                if self.session.canAddOutput(self.photoOutput) {
                    self.session.addOutput(self.photoOutput)
                }

                if #available(iOS 18.0, *), self.session.supportsControls {
                    let slider = AVCaptureSlider("调色强度", symbolName: "circle.lefthalf.filled",
                                                 in: 0.0...1.0)
                    slider.value = Float(self.store.settings.intensity)
                    let store = self.store
                    slider.setActionQueue(self.sessionQueue) { value in
                        store.settings.intensity = Double(value)
                    }
                    if self.session.canAddControl(slider) {
                        self.session.addControl(slider)
                    }
                }
                self.session.commitConfiguration()
                self.refreshFocalList()
                self.publishISORange()
            }
            if !self.session.isRunning { self.session.startRunning() }
            TraceLog.mark("session: running")
            self.setStatus("")
        }
    }

    /// Rotation (portrait) and mirroring (front camera) for both output connections.
    private func configureConnections(front: Bool) {
        if let conn = videoOutput.connection(with: .video) {
            if conn.isVideoRotationAngleSupported(90) { conn.videoRotationAngle = 90 }
            if conn.isVideoMirroringSupported { conn.isVideoMirrored = front }
        }
        if let conn = photoOutput.connection(with: .video) {
            if conn.isVideoRotationAngleSupported(90) { conn.videoRotationAngle = 90 }
            if conn.isVideoMirroringSupported { conn.isVideoMirrored = front }
        }
    }

    private func refreshFocalList() {
        let focals = Focal.allCases.filter {
            AVCaptureDevice.default($0.lens.deviceType, for: .video, position: .back) != nil
        }
        DispatchQueue.main.async { [weak self] in self?.availableFocals = focals }
    }

    private func publishISORange() {
        guard let dev = currentDevice else { return }
        let lo = dev.activeFormat.minISO
        let hi = dev.activeFormat.maxISO
        DispatchQueue.main.async { [weak self] in
            self?.manual.isoMin = lo
            self?.manual.isoMax = hi
        }
    }

    // MARK: - Focal / lens switching

    func switchFocal(_ focal: Focal) {
        guard !isFront, focal != currentFocal else { return }
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if focal.lens != self.currentLens {
                guard let device = AVCaptureDevice.default(focal.lens.deviceType, for: .video, position: .back),
                      let newInput = try? AVCaptureDeviceInput(device: device) else { return }
                self.session.beginConfiguration()
                let oldInput = self.session.inputs.compactMap { $0 as? AVCaptureDeviceInput }.first
                if let oldInput { self.session.removeInput(oldInput) }
                if self.session.canAddInput(newInput) {
                    self.session.addInput(newInput)
                } else if let oldInput, self.session.canAddInput(oldInput) {
                    self.session.addInput(oldInput)
                    self.session.commitConfiguration()
                    return
                }
                self.session.commitConfiguration()
                self.currentLens = focal.lens
                self.configureConnections(front: false)
            }
            if let dev = self.currentDevice {
                try? dev.lockForConfiguration()
                dev.videoZoomFactor = min(focal.zoom, dev.activeFormat.videoMaxZoomFactor)
                dev.unlockForConfiguration()
            }
            self.reapplyManual()
            self.publishISORange()
            DispatchQueue.main.async { [weak self] in self?.currentFocal = focal }
            TraceLog.mark("focal: switched to \(focal.mm)mm")
        }
    }

    // MARK: - Front / back flip

    func flipCamera() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            let newPos: AVCaptureDevice.Position = self.position == .back ? .front : .back
            guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: newPos),
                  let newInput = try? AVCaptureDeviceInput(device: device) else { return }
            self.session.beginConfiguration()
            let oldInput = self.session.inputs.compactMap { $0 as? AVCaptureDeviceInput }.first
            if let oldInput { self.session.removeInput(oldInput) }
            if self.session.canAddInput(newInput) {
                self.session.addInput(newInput)
            } else if let oldInput, self.session.canAddInput(oldInput) {
                self.session.addInput(oldInput)
                self.session.commitConfiguration()
                return
            }
            self.session.commitConfiguration()
            self.position = newPos
            if newPos == .back {
                self.currentLens = .wide
                if let dev = self.currentDevice {
                    try? dev.lockForConfiguration()
                    dev.videoZoomFactor = 1.0
                    dev.unlockForConfiguration()
                }
            }
            self.configureConnections(front: newPos == .front)
            self.reapplyManual()
            self.publishISORange()
            let front = newPos == .front
            DispatchQueue.main.async { [weak self] in
                self?.isFront = front
                if !front { self?.currentFocal = .f24 }
            }
            TraceLog.mark("camera: flipped to \(front ? "front" : "back")")
        }
    }

    // MARK: - Manual controls

    /// Mutates the published state on the main thread. Callers on sessionQueue that
    /// read it back through manualSnapshot() still see the new value: the main queue
    /// is FIFO, so this async mutation lands before their later sync read.
    private func updateManual(_ mutate: @escaping (inout ManualState) -> Void) {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            var m = self.manual
            mutate(&m)
            self.manual = m
        }
    }

    func setFocus(auto: Bool, value: Float) {
        sessionQueue.async { [weak self] in
            guard let self, let dev = self.currentDevice else { return }
            self.updateManual { $0.focusAuto = auto; $0.focusValue = value }
            try? dev.lockForConfiguration()
            if auto {
                if dev.isFocusModeSupported(.continuousAutoFocus) { dev.focusMode = .continuousAutoFocus }
            } else if dev.isFocusModeSupported(.locked) {
                dev.setFocusModeLocked(lensPosition: min(max(value, 0), 1), completionHandler: nil)
            }
            dev.unlockForConfiguration()
        }
    }

    func setWhiteBalance(auto: Bool, kelvin: Float) {
        sessionQueue.async { [weak self] in
            guard let self, let dev = self.currentDevice else { return }
            self.updateManual { $0.wbAuto = auto; $0.wbKelvin = kelvin }
            try? dev.lockForConfiguration()
            if auto {
                if dev.isWhiteBalanceModeSupported(.continuousAutoWhiteBalance) {
                    dev.whiteBalanceMode = .continuousAutoWhiteBalance
                }
            } else if dev.isWhiteBalanceModeSupported(.locked) {
                var gains = dev.deviceWhiteBalanceGains(
                    for: AVCaptureDevice.WhiteBalanceTemperatureAndTintValues(temperature: kelvin, tint: 0))
                let cap = dev.maxWhiteBalanceGain
                gains.redGain = min(max(gains.redGain, 1), cap)
                gains.greenGain = min(max(gains.greenGain, 1), cap)
                gains.blueGain = min(max(gains.blueGain, 1), cap)
                dev.setWhiteBalanceModeLocked(with: gains, completionHandler: nil)
            }
            dev.unlockForConfiguration()
        }
    }

    func setShutter(auto: Bool, seconds: Double) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.updateManual { $0.shutterAuto = auto; $0.shutterSeconds = seconds }
            self.applyExposure()
        }
    }

    func setISO(auto: Bool, value: Float) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.updateManual { $0.isoAuto = auto; $0.isoValue = value }
            self.applyExposure()
        }
    }

    func setEV(_ value: Float) {
        sessionQueue.async { [weak self] in
            guard let self, let dev = self.currentDevice else { return }
            let clamped = min(max(value, dev.minExposureTargetBias), dev.maxExposureTargetBias)
            self.updateManual { $0.evValue = clamped }
            try? dev.lockForConfiguration()
            dev.setExposureTargetBias(clamped, completionHandler: nil)
            dev.unlockForConfiguration()
        }
    }

    /// Shutter and ISO share one exposure mode: if either is manual the device goes
    /// custom (the still-auto side rides on the device's current reading); both auto
    /// returns to continuous auto exposure. Must be called on sessionQueue.
    private func applyExposure() {
        guard let dev = currentDevice else { return }
        let m = manualSnapshot()
        if m.shutterAuto && m.isoAuto {
            guard dev.isExposureModeSupported(.continuousAutoExposure) else { return }
            try? dev.lockForConfiguration()
            dev.exposureMode = .continuousAutoExposure
            dev.unlockForConfiguration()
            return
        }
        guard dev.isExposureModeSupported(.custom) else { return }
        let format = dev.activeFormat
        var seconds = m.shutterAuto ? CMTimeGetSeconds(dev.exposureDuration) : m.shutterSeconds
        seconds = min(max(seconds, CMTimeGetSeconds(format.minExposureDuration)),
                      CMTimeGetSeconds(format.maxExposureDuration))
        let iso = m.isoAuto ? dev.iso : min(max(m.isoValue, format.minISO), format.maxISO)
        let duration = CMTimeMakeWithSeconds(seconds, preferredTimescale: 1_000_000_000)
        try? dev.lockForConfiguration()
        dev.setExposureModeCustom(duration: duration, iso: iso, completionHandler: nil)
        dev.unlockForConfiguration()
    }

    /// `manual` is published state written on the main thread; read a consistent copy.
    private func manualSnapshot() -> ManualState {
        var result = ManualState()
        DispatchQueue.main.sync { result = self.manual }
        return result
    }

    /// Re-apply all manual settings after an input swap (a fresh device starts at defaults).
    private func reapplyManual() {
        guard let dev = currentDevice else { return }
        let m = manualSnapshot()
        // focus
        try? dev.lockForConfiguration()
        if m.focusAuto {
            if dev.isFocusModeSupported(.continuousAutoFocus) { dev.focusMode = .continuousAutoFocus }
        } else if dev.isFocusModeSupported(.locked) {
            dev.setFocusModeLocked(lensPosition: min(max(m.focusValue, 0), 1), completionHandler: nil)
        }
        // white balance
        if m.wbAuto {
            if dev.isWhiteBalanceModeSupported(.continuousAutoWhiteBalance) {
                dev.whiteBalanceMode = .continuousAutoWhiteBalance
            }
        } else if dev.isWhiteBalanceModeSupported(.locked) {
            var gains = dev.deviceWhiteBalanceGains(
                for: AVCaptureDevice.WhiteBalanceTemperatureAndTintValues(temperature: m.wbKelvin, tint: 0))
            let cap = dev.maxWhiteBalanceGain
            gains.redGain = min(max(gains.redGain, 1), cap)
            gains.greenGain = min(max(gains.greenGain, 1), cap)
            gains.blueGain = min(max(gains.blueGain, 1), cap)
            dev.setWhiteBalanceModeLocked(with: gains, completionHandler: nil)
        }
        // exposure bias
        let clampedEV = min(max(m.evValue, dev.minExposureTargetBias), dev.maxExposureTargetBias)
        dev.setExposureTargetBias(clampedEV, completionHandler: nil)
        dev.unlockForConfiguration()
        // exposure mode (shutter / ISO)
        applyExposure()
    }

    // MARK: - Capture

    func capturePhoto(handler: @escaping (Data?) -> Void) {
        TraceLog.mark("capture: requested")
        sessionQueue.async { [weak self] in
            guard let self else { handler(nil); return }
            self.photoHandler = handler
            if let conn = self.photoOutput.connection(with: .video),
               conn.isVideoRotationAngleSupported(90) {
                conn.videoRotationAngle = 90
            }
            // Deliberately the plainest possible settings: no codec dict, no quality
            // prioritization overrides — those extras are under suspicion for the
            // shutter crash and the defaults already produce full-quality HEIF/JPEG.
            let settings = AVCapturePhotoSettings()
            TraceLog.mark("capture: calling capturePhoto (session running=\(self.session.isRunning))")
            self.photoOutput.capturePhoto(with: settings, delegate: self)
        }
    }
}

@available(iOS 18.0, *)
final class ControlsDelegate: NSObject, AVCaptureSessionControlsDelegate {
    func sessionControlsDidBecomeActive(_ session: AVCaptureSession) {}
    func sessionControlsDidBecomeInactive(_ session: AVCaptureSession) {}
    func sessionControlsWillEnterFullscreenAppearance(_ session: AVCaptureSession) {}
    func sessionControlsWillExitFullscreenAppearance(_ session: AVCaptureSession) {}
}

extension CameraManager: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pb = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        let img = CIImage(cvPixelBuffer: pb)
        // Preview works on a downscaled copy so the filter chain stays cheap;
        // the photo output still captures at full sensor resolution.
        // 1080 (was 1440): one of the three anti-lag measures in v0.3.0.
        let maxSide: CGFloat = 1080
        let m = max(img.extent.width, img.extent.height)
        if m > maxSide {
            store.latestRaw = img.transformed(by: CGAffineTransform(scaleX: maxSide / m, y: maxSide / m))
        } else {
            store.latestRaw = img
        }
    }
}

extension CameraManager: AVCapturePhotoCaptureDelegate {
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        let data = error == nil ? photo.fileDataRepresentation() : nil
        TraceLog.mark("capture: delegate finished, bytes=\(data?.count ?? -1), error=\(error?.localizedDescription ?? "none")")
        let handler = photoHandler
        photoHandler = nil
        DispatchQueue.main.async { handler?(data) }
    }
}
