import AVFoundation
import CoreImage
import Foundation

/// Shared mutable frame + settings store between the camera, the settings UI and the preview renderer.
final class FrameStore {
    var latestRaw: CIImage?
    var settings = LookSettings()
}

final class CameraManager: NSObject, ObservableObject {
    @Published var statusMessage: String = "正在准备相机…"

    let store = FrameStore()

    private let session = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private let photoOutput = AVCapturePhotoOutput()
    private let sessionQueue = DispatchQueue(label: "cinelook.session")
    private var photoHandler: ((Data?) -> Void)?

    func start() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            configureAndRun()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                if granted {
                    self?.configureAndRun()
                } else {
                    self?.setStatus("没有相机权限，请到系统「设置 → 影色」里打开")
                }
            }
        default:
            setStatus("没有相机权限，请到系统「设置 → 影色」里打开")
        }
    }

    private func setStatus(_ s: String) {
        DispatchQueue.main.async { [weak self] in self?.statusMessage = s }
    }

    private func configureAndRun() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.session.inputs.isEmpty {
                self.session.beginConfiguration()
                self.session.sessionPreset = .photo
                guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
                      let input = try? AVCaptureDeviceInput(device: device),
                      self.session.canAddInput(input) else {
                    self.session.commitConfiguration()
                    self.setStatus("找不到可用的相机")
                    return
                }
                self.session.addInput(input)

                self.videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
                self.videoOutput.alwaysDiscardsLateVideoFrames = true
                if self.session.canAddOutput(self.videoOutput) {
                    self.session.addOutput(self.videoOutput)
                    self.videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "cinelook.video"))
                    if let conn = self.videoOutput.connection(with: .video),
                       conn.isVideoRotationAngleSupported(90) {
                        conn.videoRotationAngle = 90
                    }
                }
                if self.session.canAddOutput(self.photoOutput) {
                    self.session.addOutput(self.photoOutput)
                }
                self.session.commitConfiguration()
            }
            if !self.session.isRunning { self.session.startRunning() }
            self.setStatus("")
        }
    }

    func capturePhoto(handler: @escaping (Data?) -> Void) {
        sessionQueue.async { [weak self] in
            guard let self else { handler(nil); return }
            self.photoHandler = handler
            if let conn = self.photoOutput.connection(with: .video),
               conn.isVideoRotationAngleSupported(90) {
                conn.videoRotationAngle = 90
            }
            let settings: AVCapturePhotoSettings
            if self.photoOutput.availablePhotoCodecTypes.contains(.hevc) {
                settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.hevc])
            } else {
                settings = AVCapturePhotoSettings()
            }
            settings.photoQualityPrioritization = .quality
            self.photoOutput.capturePhoto(with: settings, delegate: self)
        }
    }
}

extension CameraManager: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pb = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        let img = CIImage(cvPixelBuffer: pb)
        // Preview works on a downscaled copy so the filter chain stays cheap;
        // the photo output still captures at full sensor resolution.
        let maxSide: CGFloat = 1440
        let m = max(img.extent.width, img.extent.height)
        if m > maxSide {
            store.latestRaw = img.transformed(by: CGAffineTransform(scaleX: maxSide / m, y: maxSide / m))
        } else {
            store.latestRaw = img
        }
    }
}

extension CameraManager: AVCapturePhotoCaptureDelegate {
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        let data = error == nil ? photo.fileDataRepresentation() : nil
        let handler = photoHandler
        photoHandler = nil
        DispatchQueue.main.async { handler?(data) }
    }
}
