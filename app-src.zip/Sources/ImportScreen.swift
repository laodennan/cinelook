import SwiftUI
import PhotosUI
import CoreImage
import ImageIO

/// Import an existing photo (JPEG / HEIF / RAW) and give it the look.
struct ImportScreen: View {
    @EnvironmentObject var library: LookLibrary
    @Environment(\.dismiss) private var dismiss
    @State private var pickerItem: PhotosPickerItem?
    @State private var showPicker = false
    @State private var original: CIImage?
    @State private var preview: UIImage?
    @State private var settings = LookSettings()
    @State private var isSaving = false
    @State private var toast: String?
    @State private var shots: [URL] = []
    @State private var selectedShot: URL?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 12) {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text("导入").font(.title3.bold())
                    Text("给老照片套上电影风格").font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    Button("关闭") { dismiss() }
                        .font(.body)
                }
                .padding(.horizontal)

                ZStack {
                    RoundedRectangle(cornerRadius: 18)
                        .fill(Color.white.opacity(0.05))
                    if let preview {
                        Image(uiImage: preview)
                            .resizable()
                            .scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 18))
                    } else {
                        VStack(spacing: 10) {
                            Image(systemName: "photo.on.rectangle.angled")
                                .font(.system(size: 40))
                                .foregroundStyle(.secondary)
                            Text("还没选照片")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                .padding(.horizontal)

                LookControls(settings: $settings)
                    .padding(.horizontal)

                if !shots.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("本机拍摄")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(shots, id: \.self) { url in
                                    Button {
                                        loadShot(url)
                                    } label: {
                                        if let thumb = Self.thumbnail(for: url) {
                                            Image(uiImage: thumb)
                                                .resizable()
                                                .scaledToFill()
                                                .frame(width: 54, height: 54)
                                                .clipShape(RoundedRectangle(cornerRadius: 10))
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 10)
                                                        .stroke(selectedShot == url ? Color.orange : Color.clear,
                                                                lineWidth: 2))
                                        }
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                    }
                    .padding(.horizontal)
                }

                HStack(spacing: 12) {
                    Button {
                        showPicker = true
                    } label: {
                        Text("选择照片")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
                    }
                    Button {
                        save()
                    } label: {
                        Text(isSaving ? "保存中…" : "保存到相册")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(original == nil || isSaving ? Color.orange.opacity(0.35) : Color.orange,
                                        in: RoundedRectangle(cornerRadius: 14))
                            .foregroundStyle(.black)
                    }
                    .disabled(original == nil || isSaving)
                }
                .padding(.horizontal)
                .padding(.bottom, 4)

                HStack(spacing: 16) {
                    Text("LumaCam 0.4.2")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                    Spacer()
                    ShareLink(item: TraceLog.fileURL) {
                        Label("分享诊断日志", systemImage: "doc.text")
                            .font(.caption)
                    }
                }
                .padding(.horizontal)
            }
            .padding(.vertical, 10)

            if let toast {
                VStack {
                    Spacer()
                    Text(toast)
                        .font(.subheadline)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(.ultraThickMaterial, in: Capsule())
                        .padding(.bottom, 130)
                }
                .transition(.opacity)
            }
        }
        .photosPicker(isPresented: $showPicker, selection: $pickerItem, matching: .images)
        .onAppear {
            settings.lutID = library.selectedID
            shots = ShotsStore.list()
            // Open on the newest photo this camera took, instead of a blank page.
            if original == nil, let newest = shots.first {
                loadShot(newest)
            }
        }
        .onChange(of: pickerItem) { _, item in load(item) }
        .onChange(of: settings) { _, _ in refreshPreview() }
        .onChange(of: library.selectedID) { _, id in settings.lutID = id }
    }

    private func load(_ item: PhotosPickerItem?) {
        guard let item else { return }
        Task {
            guard let data = try? await item.loadTransferable(type: Data.self) else {
                showToast("这张照片读取失败，换一张试试")
                return
            }
            let image = Self.makeCIImage(from: data)
            await MainActor.run {
                selectedShot = nil
                original = image
                refreshPreview()
                if image == nil { showToast("这张照片的格式暂时读不了") }
            }
        }
    }

    private func loadShot(_ url: URL) {
        selectedShot = url
        Task {
            let data = try? Data(contentsOf: url)
            let image = data.flatMap { Self.makeCIImage(from: $0) }
            await MainActor.run {
                original = image
                refreshPreview()
                if image == nil { showToast("这张拍好的照片读不出来") }
            }
        }
    }

    private static func thumbnail(for url: URL) -> UIImage? {
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
        let opts: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: 160,
        ]
        guard let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) else { return nil }
        return UIImage(cgImage: cg)
    }

    private static func makeCIImage(from data: Data) -> CIImage? {
        // RAW (e.g. ProRAW DNG) first; fall back to regular decode.
        if let rawFilter = CIRAWFilter(imageData: data, identifierHint: nil),
           let out = rawFilter.outputImage {
            return out
        }
        if let ci = CIImage(data: data) {
            return orientedFromEXIF(ci)
        }
        return nil
    }

    private func refreshPreview() {
        guard let original else { preview = nil; return }
        var src = original
        let maxSide: CGFloat = 1600
        let m = max(src.extent.width, src.extent.height)
        if m > maxSide {
            src = src.transformed(by: CGAffineTransform(scaleX: maxSide / m, y: maxSide / m))
        }
        let processed = LookEngine.shared.apply(to: src, settings: settings, grainSeed: 42)
        if let cg = LookEngine.shared.context.createCGImage(processed, from: processed.extent) {
            preview = UIImage(cgImage: cg)
        }
    }

    private func save() {
        guard let original, !isSaving else { return }
        isSaving = true
        let current = settings
        // Imported photos get the model/date lines only: params describe a live
        // capture, and the location/weather of an old photo is not "now".
        let wm = WatermarkStore.shared
        var lines: [String] = []
        if wm.enabled {
            if wm.showModel { lines.append(WatermarkService.modelName()) }
            if wm.showDate,
               let exif = original.properties[kCGImagePropertyExifDictionary as String] as? [String: Any],
               let stamp = exif[kCGImagePropertyExifDateTimeOriginal as String] as? String {
                let parser = DateFormatter()
                parser.dateFormat = "yyyy:MM:dd HH:mm:ss"
                if let date = parser.date(from: stamp) {
                    let f = DateFormatter()
                    f.locale = Locale(identifier: "zh_CN")
                    f.dateFormat = "yyyy年M月d日 HH:mm"
                    lines.append(f.string(from: date))
                }
            }
        }
        let position = wm.position
        DispatchQueue.global(qos: .userInitiated).async {
            let processed = LookEngine.shared.apply(
                to: cappedForProcessing(original), settings: current,
                grainSeed: CGFloat(Int.random(in: 0...100_000)))
            PhotoSaver.save(processed, watermarkLines: lines, watermarkPosition: position) { ok in
                isSaving = false
                showToast(ok ? "已保存到相册" : "保存失败，请检查相册权限")
            }
        }
    }

    private func showToast(_ message: String) {
        toast = message
        Task {
            try? await Task.sleep(nanoseconds: 2_000_000_000)
            if toast == message { toast = nil }
        }
    }
}
