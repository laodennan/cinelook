import SwiftUI
import PhotosUI
import CoreImage

/// Import an existing photo (JPEG / HEIF / RAW) and give it the look.
struct ImportScreen: View {
    @State private var pickerItem: PhotosPickerItem?
    @State private var showPicker = false
    @State private var original: CIImage?
    @State private var preview: UIImage?
    @State private var settings = LookSettings()
    @State private var isSaving = false
    @State private var toast: String?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 12) {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text("导入").font(.title3.bold())
                    Text("给老照片套上电影风格").font(.caption).foregroundStyle(.secondary)
                    Spacer()
                }
                .padding(.horizontal)

                ZStack {
                    RoundedRectangle(cornerRadius: 18)
                        .fill(Color.white.opacity(0.05))
                    if let preview {
                        Image(uiImage: preview)
                            .resizable()
                            .scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 18))
                    } else {
                        VStack(spacing: 10) {
                            Image(systemName: "photo.on.rectangle.angled")
                                .font(.system(size: 40))
                                .foregroundStyle(.secondary)
                            Text("还没选照片")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                .padding(.horizontal)

                LookControls(settings: $settings)
                    .padding(.horizontal)

                HStack(spacing: 12) {
                    Button {
                        showPicker = true
                    } label: {
                        Text("选择照片")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
                    }
                    Button {
                        save()
                    } label: {
                        Text(isSaving ? "保存中…" : "保存到相册")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(original == nil || isSaving ? Color.orange.opacity(0.35) : Color.orange,
                                        in: RoundedRectangle(cornerRadius: 14))
                            .foregroundStyle(.black)
                    }
                    .disabled(original == nil || isSaving)
                }
                .padding(.horizontal)
                .padding(.bottom, 4)
            }
            .padding(.vertical, 10)

            if let toast {
                VStack {
                    Spacer()
                    Text(toast)
                        .font(.subheadline)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(.ultraThickMaterial, in: Capsule())
                        .padding(.bottom, 130)
                }
                .transition(.opacity)
            }
        }
        .photosPicker(isPresented: $showPicker, selection: $pickerItem, matching: .images)
        .onChange(of: pickerItem) { _, item in load(item) }
        .onChange(of: settings) { _, _ in refreshPreview() }
    }

    private func load(_ item: PhotosPickerItem?) {
        guard let item else { return }
        Task {
            guard let data = try? await item.loadTransferable(type: Data.self) else {
                showToast("这张照片读取失败，换一张试试")
                return
            }
            let image = Self.makeCIImage(from: data)
            await MainActor.run {
                original = image
                refreshPreview()
                if image == nil { showToast("这张照片的格式暂时读不了") }
            }
        }
    }

    private static func makeCIImage(from data: Data) -> CIImage? {
        // RAW (e.g. ProRAW DNG) first; fall back to regular decode.
        if let rawFilter = CIRAWFilter(imageData: data, identifierHint: nil),
           let out = rawFilter.outputImage {
            return out
        }
        if let ci = CIImage(data: data) {
            return orientedFromEXIF(ci)
        }
        return nil
    }

    private func refreshPreview() {
        guard let original else { preview = nil; return }
        var src = original
        let maxSide: CGFloat = 1600
        let m = max(src.extent.width, src.extent.height)
        if m > maxSide {
            src = src.transformed(by: CGAffineTransform(scaleX: maxSide / m, y: maxSide / m))
        }
        let processed = LookEngine.shared.apply(to: src, settings: settings, grainSeed: 42)
        if let cg = LookEngine.shared.context.createCGImage(processed, from: processed.extent) {
            preview = UIImage(cgImage: cg)
        }
    }

    private func save() {
        guard let original, !isSaving else { return }
        isSaving = true
        let processed = LookEngine.shared.apply(
            to: original, settings: settings,
            grainSeed: CGFloat(Int.random(in: 0...100_000)))
        PhotoSaver.save(processed) { ok in
            isSaving = false
            showToast(ok ? "已保存到相册" : "保存失败，请检查相册权限")
        }
    }

    private func showToast(_ message: String) {
        toast = message
        Task {
            try? await Task.sleep(nanoseconds: 2_000_000_000)
            if toast == message { toast = nil }
        }
    }
}
