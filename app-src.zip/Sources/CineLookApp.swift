import SwiftUI

@main
struct CineLookApp: App {
    @StateObject private var library = LookLibrary()

    init() {
        TraceLog.mark("app: launch, version 0.2.1")
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(library)
        }
    }
}

struct RootView: View {
    @State private var selection = 0

    var body: some View {
        TabView(selection: $selection) {
            CameraScreen(goImport: { selection = 1 })
                .tabItem { Label("相机", systemImage: "camera.fill") }
                .tag(0)
            ImportScreen()
                .tabItem { Label("导入", systemImage: "photo.on.rectangle.angled") }
                .tag(1)
        }
        .preferredColorScheme(.dark)
        .tint(.orange)
    }
}
