import SwiftUI

@main
struct CineLookApp: App {
    @StateObject private var library = LookLibrary()

    init() {
        TraceLog.mark("app: launch, version 0.2.2")
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(library)
        }
    }
}

struct RootView: View {
    var body: some View {
        // No TabView: the tab bar overlapped the shutter row and ate its taps (v0.2.1 bug).
        // Import is a full-screen cover from the camera screen, like the stock app's library.
        CameraScreen()
            .preferredColorScheme(.dark)
            .tint(.orange)
    }
}
