import SwiftUI

@main
struct CineLookApp: App {
    @StateObject private var library = LookLibrary()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(library)
        }
    }
}

struct RootView: View {
    var body: some View {
        TabView {
            CameraScreen()
                .tabItem { Label("相机", systemImage: "camera.fill") }
            ImportScreen()
                .tabItem { Label("导入", systemImage: "photo.on.rectangle.angled") }
        }
        .preferredColorScheme(.dark)
        .tint(.orange)
    }
}
