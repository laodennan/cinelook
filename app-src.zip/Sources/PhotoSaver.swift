import CoreImage
import Photos
import Foundation

enum PhotoSaver {
    /// Renders the image as HEIF and adds it to the user's photo library.
    /// Rendering happens on a background queue: a full-resolution render on the main
    /// thread can stall long enough for the system to kill the app.
    static func save(_ image: CIImage, completion: @escaping (Bool) -> Void) {
        save(image, watermarkLines: [], watermarkPosition: .bottomLeft, completion: completion)
    }

    static func save(_ image: CIImage, watermarkLines: [String], watermarkPosition: WMPosition,
                     completion: @escaping (Bool) -> Void) {
        TraceLog.mark("save: render begin \(Int(image.extent.width))x\(Int(image.extent.height))")
        DispatchQueue.global(qos: .userInitiated).async {
            let ctx = CIContext()
            var finalImage = image
            if !watermarkLines.isEmpty {
                if let burned = Watermark.burn(lines: watermarkLines, position: watermarkPosition,
                                               into: image, context: ctx) {
                    finalImage = burned
                    TraceLog.mark("save: watermark burned (\(watermarkLines.count) lines)")
                } else {
                    TraceLog.mark("save: watermark burn FAILED, saving without")
                }
            }
            guard let colorSpace = CGColorSpace(name: CGColorSpace.sRGB),
                  let data = ctx.heifRepresentation(of: finalImage, format: .RGBA8, colorSpace: colorSpace) else {
                TraceLog.mark("save: HEIF render FAILED")
                DispatchQueue.main.async { completion(false) }
                return
            }
            TraceLog.mark("save: HEIF rendered, bytes=\(data.count)")
            PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
                TraceLog.mark("save: addOnly authorization=\(status.rawValue)")
                guard status == .authorized || status == .limited else {
                    DispatchQueue.main.async { completion(false) }
                    return
                }
                PHPhotoLibrary.shared().performChanges({
                    let request = PHAssetCreationRequest.forAsset()
                    request.addResource(with: .photo, data: data, options: nil)
                }, completionHandler: { ok, err in
                    TraceLog.mark("save: library write ok=\(ok), error=\(err?.localizedDescription ?? "none")")
                    DispatchQueue.main.async { completion(ok) }
                })
            }
        }
    }
}
