import CoreImage
import ImageIO
import Photos
import Foundation
import UniformTypeIdentifiers

/// v0.5.0 rewrite of the save path. The image arrives with orientation
/// already baked into its pixels (see StillImage). Saving is then a straight
/// line with no metadata interpretation anywhere:
///   CIImage → render once to CGImage → optional watermark burn (CG space,
///   final step) → HEIF encode with an explicit orientation of 1 → Photos.
/// The v0.4.x version encoded straight from the CIImage and let the writer
/// inherit whatever orientation metadata the transform chain had produced.
enum PhotoSaver {
    static func save(_ image: CIImage, completion: @escaping (Bool) -> Void) {
        save(image, watermarkLines: [], watermarkPosition: .bottomLeft, recordAsShot: false, completion: completion)
    }

    static func save(_ image: CIImage, watermarkLines: [String], watermarkPosition: WMPosition,
                     recordAsShot: Bool = false,
                     completion: @escaping (Bool) -> Void) {
        TraceLog.mark("save: render begin \(Int(image.extent.width))x\(Int(image.extent.height))")
        DispatchQueue.global(qos: .userInitiated).async {
            let ctx = CIContext()
            guard let rendered = ctx.createCGImage(image, from: image.extent) else {
                TraceLog.mark("save: render FAILED")
                DispatchQueue.main.async { completion(false) }
                return
            }
            var finalCG = rendered
            if !watermarkLines.isEmpty {
                if let burned = WatermarkBurn.burn(lines: watermarkLines, position: watermarkPosition, into: rendered) {
                    finalCG = burned
                    TraceLog.mark("save: watermark burned (\(watermarkLines.count) lines)")
                } else {
                    TraceLog.mark("save: watermark burn FAILED, saving without")
                }
            }
            guard let data = heifData(from: finalCG) else {
                TraceLog.mark("save: HEIF encode FAILED")
                DispatchQueue.main.async { completion(false) }
                return
            }
            TraceLog.mark("save: HEIF encoded, bytes=\(data.count)")
            PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
                TraceLog.mark("save: addOnly authorization=\(status.rawValue)")
                guard status == .authorized || status == .limited else {
                    DispatchQueue.main.async { completion(false) }
                    return
                }
                PHPhotoLibrary.shared().performChanges({
                    let request = PHAssetCreationRequest.forAsset()
                    request.addResource(with: .photo, data: data, options: nil)
                }, completionHandler: { ok, err in
                    TraceLog.mark("save: library write ok=\(ok), error=\(err?.localizedDescription ?? "none")")
                    if ok && recordAsShot {
                        ShotsStore.recordShot(finalCG)
                    }
                    DispatchQueue.main.async { completion(ok) }
                })
            }
        }
    }

    /// HEIF-encode a CGImage with the orientation stated explicitly as 1:
    /// the pixels are already upright, and nothing is left to interpretation.
    private static func heifData(from cg: CGImage) -> Data? {
        let out = NSMutableData()
        guard let dest = CGImageDestinationCreateWithData(
            out, UTType.heic.identifier as CFString, 1, nil) else { return nil }
        let options: [CFString: Any] = [
            kCGImageDestinationLossyCompressionQuality: 0.92,
            kCGImagePropertyOrientation: 1,
        ]
        CGImageDestinationAddImage(dest, cg, options as CFDictionary)
        guard CGImageDestinationFinalize(dest) else { return nil }
        return out as Data
    }
}
