import CoreImage
import Photos
import Foundation

enum PhotoSaver {
    /// Renders the image as HEIF and adds it to the user's photo library.
    /// Rendering happens on a background queue: a full-resolution render on the main
    /// thread can stall long enough for the system to kill the app.
    static func save(_ image: CIImage, completion: @escaping (Bool) -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            let ctx = CIContext()
            guard let colorSpace = CGColorSpace(name: CGColorSpace.sRGB),
                  let data = ctx.heifRepresentation(of: image, format: .RGBA8, colorSpace: colorSpace) else {
                DispatchQueue.main.async { completion(false) }
                return
            }
            PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
                guard status == .authorized || status == .limited else {
                    DispatchQueue.main.async { completion(false) }
                    return
                }
                PHPhotoLibrary.shared().performChanges({
                    let request = PHAssetCreationRequest.forAsset()
                    request.addResource(with: .photo, data: data, options: nil)
                }, completionHandler: { ok, _ in
                    DispatchQueue.main.async { completion(ok) }
                })
            }
        }
    }
}
