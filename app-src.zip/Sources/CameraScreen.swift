import SwiftUI
import CoreImage

/// Shared controls for the look: LUT picker, intensity, grain, halation, monochrome.
struct LookControls: View {
    @Binding var settings: LookSettings
    @EnvironmentObject var library: LookLibrary
    @State private var showLookPicker = false

    var body: some View {
        VStack(spacing: 14) {
            HStack(spacing: 10) {
                Text("调色")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Button {
                    showLookPicker = true
                } label: {
                    HStack(spacing: 5) {
                        Text(library.selectedItem.title)
                            .lineLimit(1)
                        Image(systemName: "chevron.up.chevron.down")
                            .font(.caption2)
                    }
                    .font(.subheadline)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(Color.white.opacity(0.12), in: Capsule())
                    .foregroundStyle(.primary)
                }
                Spacer()
            }
            HStack(spacing: 10) {
                Text("强度")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Slider(value: $settings.intensity, in: 0...1)
                Text("\(Int(settings.intensity * 100))")
                    .font(.subheadline.monospacedDigit())
                    .foregroundStyle(.secondary)
                    .frame(width: 30, alignment: .trailing)
            }
            HStack(spacing: 16) {
                HStack(spacing: 8) {
                    Text("颗粒").font(.subheadline).foregroundStyle(.secondary)
                    Picker("颗粒", selection: $settings.grain) {
                        Text("关").tag(0)
                        Text("细").tag(1)
                        Text("粗").tag(2)
                    }
                    .pickerStyle(.segmented)
                    .frame(width: 148)
                }
                Spacer()
                HStack(spacing: 6) {
                    Text("光晕").font(.subheadline).foregroundStyle(.secondary)
                    Toggle("", isOn: $settings.halation).labelsHidden()
                }
                HStack(spacing: 6) {
                    Text("黑白").font(.subheadline).foregroundStyle(.secondary)
                    Toggle("", isOn: $settings.monochrome).labelsHidden()
                }
            }
        }
        .padding(14)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
        .sheet(isPresented: $showLookPicker) {
            LookPickerView()
        }
    }
}

struct CameraScreen: View {
    @StateObject private var camera = CameraManager()
    @EnvironmentObject var library: LookLibrary
    @State private var settings = LookSettings()
    @State private var isCapturing = false
    @State private var toast: String?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 12) {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text("LumaCam").font(.title3.bold())
                    Text("电影相机").font(.caption).foregroundStyle(.secondary)
                    Spacer()
                }
                .padding(.horizontal)

                ZStack {
                    PreviewView(store: camera.store)
                        .clipShape(RoundedRectangle(cornerRadius: 18))
                    if !camera.statusMessage.isEmpty {
                        Text(camera.statusMessage)
                            .multilineTextAlignment(.center)
                            .padding()
                    }
                }
                .padding(.horizontal)

                LookControls(settings: $settings)
                    .padding(.horizontal)

                if camera.availableLenses.count > 1 {
                    HStack(spacing: 10) {
                        ForEach(camera.availableLenses, id: \.self) { lens in
                            Button {
                                camera.switchLens(lens)
                            } label: {
                                Text(lens.label)
                                    .font(.subheadline.bold())
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 7)
                                    .background(camera.currentLens == lens
                                                ? Color.white : Color.white.opacity(0.14),
                                                in: Capsule())
                                    .foregroundStyle(camera.currentLens == lens ? .black : .white)
                            }
                        }
                    }
                }

                HStack {
                    Spacer()
                    Button(action: shutter) {
                        ZStack {
                            Circle().stroke(Color.white, lineWidth: 4)
                                .frame(width: 74, height: 74)
                            Circle().fill(isCapturing ? Color.gray : Color.white)
                                .frame(width: 60, height: 60)
                        }
                    }
                    .disabled(isCapturing)
                    Spacer()
                }
                .padding(.bottom, 4)
            }
            .padding(.vertical, 10)

            if let toast {
                VStack {
                    Spacer()
                    Text(toast)
                        .font(.subheadline)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(.ultraThickMaterial, in: Capsule())
                        .padding(.bottom, 130)
                }
                .transition(.opacity)
            }
        }
        .onAppear {
            settings.lutID = library.selectedID
            camera.start()
            camera.store.settings = settings
        }
        .onChange(of: settings) { _, new in
            camera.store.settings = new
        }
        .onChange(of: library.selectedID) { _, id in
            settings.lutID = id
        }
    }

    private func shutter() {
        guard !isCapturing else { return }
        isCapturing = true
        let current = settings
        camera.capturePhoto { data in
            guard let data else {
                isCapturing = false
                showToast("拍照失败，再试一次")
                return
            }
            // Process off the main thread: full-resolution grading on the main thread
            // can stall the app into a watchdog kill.
            DispatchQueue.global(qos: .userInitiated).async {
                guard let raw = CIImage(data: data) else {
                    DispatchQueue.main.async {
                        isCapturing = false
                        showToast("拍照失败，再试一次")
                    }
                    return
                }
                let image = cappedForProcessing(orientedFromEXIF(raw))
                let processed = LookEngine.shared.apply(
                    to: image, settings: current,
                    grainSeed: CGFloat(Int.random(in: 0...100_000)))
                PhotoSaver.save(processed) { ok in
                    isCapturing = false
                    showToast(ok ? "已保存到相册" : "保存失败，请检查相册权限")
                }
            }
        }
    }

    private func showToast(_ message: String) {
        toast = message
        Task {
            try? await Task.sleep(nanoseconds: 2_000_000_000)
            if toast == message { toast = nil }
        }
    }
}
