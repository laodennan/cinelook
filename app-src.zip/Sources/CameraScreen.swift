import SwiftUI
import CoreImage

/// Shared controls for the look: LUT picker, intensity, grain, halation, monochrome.
struct LookControls: View {
    @Binding var settings: LookSettings
    @EnvironmentObject var library: LookLibrary
    @State private var showLookPicker = false

    var body: some View {
        VStack(spacing: 14) {
            HStack(spacing: 10) {
                Text("调色")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Button {
                    showLookPicker = true
                } label: {
                    HStack(spacing: 5) {
                        Text(library.selectedItem.title)
                            .lineLimit(1)
                        Image(systemName: "chevron.up.chevron.down")
                            .font(.caption2)
                    }
                    .font(.subheadline)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(Color.white.opacity(0.12), in: Capsule())
                    .foregroundStyle(.primary)
                }
                Spacer()
            }
            HStack(spacing: 10) {
                Text("强度")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Slider(value: $settings.intensity, in: 0...1)
                Text("\(Int(settings.intensity * 100))")
                    .font(.subheadline.monospacedDigit())
                    .foregroundStyle(.secondary)
                    .frame(width: 30, alignment: .trailing)
            }
            HStack(spacing: 10) {
                Text("颗粒")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Picker("颗粒", selection: $settings.grain) {
                    Text("关").tag(0)
                    Text("细").tag(1)
                    Text("粗").tag(2)
                }
                .pickerStyle(.segmented)
            }
            HStack {
                HStack(spacing: 8) {
                    Text("光晕").font(.subheadline).foregroundStyle(.secondary)
                    Toggle("", isOn: $settings.halation).labelsHidden()
                }
                Spacer()
                HStack(spacing: 8) {
                    Text("黑白").font(.subheadline).foregroundStyle(.secondary)
                    Toggle("", isOn: $settings.monochrome).labelsHidden()
                }
                Spacer()
            }
        }
        .padding(14)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
        .sheet(isPresented: $showLookPicker) {
            LookPickerView()
        }
    }
}

/// Camera screen modeled on the iOS stock Camera app: full-bleed preview,
/// black bottom control zone, zoom pills, big shutter, slide-up adjustments.
struct CameraScreen: View {
    @StateObject private var camera = CameraManager()
    @EnvironmentObject var library: LookLibrary
    @State private var settings = LookSettings()
    @State private var isCapturing = false
    @State private var toast: String?
    @State private var showControls = false
    @State private var showLookPicker = false
    @State private var showImport = false
    @State private var lastShot: UIImage?

    var body: some View {
        ZStack {
            PreviewView(store: camera.store)
                .ignoresSafeArea()

            // top bar over a soft gradient, like the stock app
            VStack {
                HStack {
                    Text("LumaCam")
                        .font(.subheadline.weight(.semibold))
                        .shadow(radius: 4)
                    Spacer()
                    Button {
                        showLookPicker = true
                    } label: {
                        HStack(spacing: 5) {
                            Image(systemName: "camera.filters")
                            Text(library.selectedItem.title).lineLimit(1)
                        }
                        .font(.subheadline)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(Color.black.opacity(0.35), in: Capsule())
                    }
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 16)
                .padding(.top, 8)
                Spacer()
            }
            .background(alignment: .top) {
                LinearGradient(colors: [.black.opacity(0.45), .clear],
                               startPoint: .top, endPoint: .bottom)
                    .frame(height: 110)
                    .ignoresSafeArea(edges: .top)
                    .allowsHitTesting(false)
            }

            if !camera.statusMessage.isEmpty {
                Text(camera.statusMessage)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .background(.ultraThinMaterial, in: Capsule())
            }

            // bottom control zone
            VStack {
                Spacer()
                VStack(spacing: 12) {
                    if showControls {
                        LookControls(settings: $settings)
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                    }

                    Button {
                        withAnimation(.easeInOut(duration: 0.22)) { showControls.toggle() }
                    } label: {
                        Image(systemName: showControls ? "chevron.down" : "chevron.up")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(.white.opacity(0.85))
                            .frame(width: 44, height: 24)
                    }

                    if camera.availableLenses.count > 1 {
                        HStack(spacing: 2) {
                            ForEach(camera.availableLenses, id: \.self) { lens in
                                Button {
                                    camera.switchLens(lens)
                                } label: {
                                    Text(lens.label)
                                        .font(.system(size: 13, weight: .semibold))
                                        .foregroundStyle(camera.currentLens == lens ? .yellow : .white)
                                        .frame(width: 38, height: 30)
                                        .background(camera.currentLens == lens
                                                    ? Color.white.opacity(0.22) : Color.clear,
                                                    in: Circle())
                                }
                            }
                        }
                        .padding(3)
                        .background(Color.black.opacity(0.45), in: Capsule())
                    }

                    HStack {
                        Button { showImport = true } label: {
                            Group {
                                if let lastShot {
                                    Image(uiImage: lastShot)
                                        .resizable()
                                        .scaledToFill()
                                } else {
                                    Image(systemName: "photo.on.rectangle")
                                        .font(.system(size: 20))
                                        .foregroundStyle(.white)
                                }
                            }
                            .frame(width: 46, height: 46)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                            .overlay(RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.white.opacity(0.7), lineWidth: 1.5))
                        }
                        .frame(maxWidth: .infinity)

                        Button(action: shutter) {
                            ZStack {
                                Circle().stroke(Color.white, lineWidth: 4.5)
                                    .frame(width: 72, height: 72)
                                Circle().fill(isCapturing ? Color.gray : Color.white)
                                    .frame(width: 60, height: 60)
                            }
                        }
                        .disabled(isCapturing)
                        .frame(maxWidth: .infinity)

                        Button {
                            showLookPicker = true
                        } label: {
                            Image(systemName: "wand.and.stars")
                                .font(.system(size: 20))
                                .foregroundStyle(.white)
                                .frame(width: 46, height: 46)
                                .background(Color.white.opacity(0.16), in: Circle())
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .padding(.horizontal, 30)
                }
                .padding(.top, 10)
                .padding(.bottom, 18)
                .background(
                    LinearGradient(colors: [.clear, .black.opacity(0.88)],
                                   startPoint: .top, endPoint: .bottom)
                )
            }
            .ignoresSafeArea(edges: .bottom)

            if let toast {
                VStack {
                    Spacer()
                    Text(toast)
                        .font(.subheadline)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(.ultraThickMaterial, in: Capsule())
                        .padding(.bottom, 250)
                }
                .transition(.opacity)
            }
        }
        .background(Color.black)
        .sheet(isPresented: $showLookPicker) {
            LookPickerView()
        }
        .fullScreenCover(isPresented: $showImport) {
            ImportScreen()
        }
        .onAppear {
            settings.lutID = library.selectedID
            camera.start()
            camera.store.settings = settings
            TraceLog.mark("ui: camera screen appeared")
        }
        .onChange(of: settings) { _, new in
            camera.store.settings = new
        }
        .onChange(of: library.selectedID) { _, id in
            settings.lutID = id
        }
    }

    private func shutter() {
        guard !isCapturing else { return }
        isCapturing = true
        TraceLog.mark("shutter: tap")
        let current = settings
        camera.capturePhoto { data in
            if let data {
                DispatchQueue.global(qos: .userInitiated).async {
                    guard let raw = CIImage(data: data) else {
                        TraceLog.mark("shutter: photo data could not be decoded")
                        finishWithFallback(current)
                        return
                    }
                    TraceLog.mark("shutter: photo decoded \(Int(raw.extent.width))x\(Int(raw.extent.height))")
                    processAndSave(cappedForProcessing(orientedFromEXIF(raw)), settings: current)
                }
            } else {
                finishWithFallback(current)
            }
        }
    }

    /// If the photo pipeline fails, still deliver a graded frame from the live preview
    /// rather than dying or silently doing nothing.
    private func finishWithFallback(_ current: LookSettings) {
        TraceLog.mark("shutter: falling back to latest preview frame")
        guard let frame = camera.store.latestRaw else {
            DispatchQueue.main.async {
                isCapturing = false
                showToast("拍照失败，再试一次")
            }
            return
        }
        processAndSave(frame, settings: current)
    }

    private func processAndSave(_ image: CIImage, settings current: LookSettings) {
        TraceLog.mark("process: begin")
        let processed = LookEngine.shared.apply(
            to: image, settings: current,
            grainSeed: CGFloat(Int.random(in: 0...100_000)))
        TraceLog.mark("process: chain built")
        // thumbnail for the bottom-left corner, rendered off a downscaled copy
        let thumbScale = 240 / max(processed.extent.width, 1)
        let thumbImage = processed.transformed(by: CGAffineTransform(scaleX: thumbScale, y: thumbScale))
        if let cg = LookEngine.shared.context.createCGImage(thumbImage, from: thumbImage.extent) {
            let thumb = UIImage(cgImage: cg)
            DispatchQueue.main.async { lastShot = thumb }
        }
        PhotoSaver.save(processed) { ok in
            isCapturing = false
            TraceLog.mark("shutter: flow completed, saved=\(ok)")
            showToast(ok ? "已保存到相册" : "保存失败，请检查相册权限")
        }
    }

    private func showToast(_ message: String) {
        toast = message
        Task {
            try? await Task.sleep(nanoseconds: 2_000_000_000)
            if toast == message { toast = nil }
        }
    }
}
