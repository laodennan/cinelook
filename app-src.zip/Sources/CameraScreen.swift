import SwiftUI
import CoreImage

/// Shared controls for the look: LUT picker, intensity, grain, halation, monochrome.
struct LookControls: View {
    @Binding var settings: LookSettings
    @EnvironmentObject var library: LookLibrary
    @State private var showLookPicker = false
    @ObservedObject private var watermark = WatermarkStore.shared
    @State private var showWatermarkSettings = false

    var body: some View {
        VStack(spacing: 14) {
            HStack(spacing: 10) {
                Text("调色")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Button {
                    showLookPicker = true
                } label: {
                    HStack(spacing: 5) {
                        Text(library.selectedItem.title)
                            .lineLimit(1)
                        Image(systemName: "chevron.up.chevron.down")
                            .font(.caption2)
                    }
                    .font(.subheadline)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(Color.white.opacity(0.12), in: Capsule())
                    .foregroundStyle(.primary)
                }
                Spacer()
            }
            HStack(spacing: 10) {
                Text("强度")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Slider(value: $settings.intensity, in: 0...1)
                Text("\(Int(settings.intensity * 100))")
                    .font(.subheadline.monospacedDigit())
                    .foregroundStyle(.secondary)
                    .frame(width: 30, alignment: .trailing)
            }
            HStack(spacing: 10) {
                Text("颗粒")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Picker("颗粒", selection: $settings.grain) {
                    Text("关").tag(0)
                    Text("细").tag(1)
                    Text("粗").tag(2)
                }
                .pickerStyle(.segmented)
            }
            HStack {
                HStack(spacing: 8) {
                    Text("光晕").font(.subheadline).foregroundStyle(.secondary)
                    Toggle("", isOn: $settings.halation).labelsHidden()
                }
                Spacer()
                HStack(spacing: 8) {
                    Text("黑白").font(.subheadline).foregroundStyle(.secondary)
                    Toggle("", isOn: $settings.monochrome).labelsHidden()
                }
                Spacer()
            }
            HStack(spacing: 8) {
                Text("水印").font(.subheadline).foregroundStyle(.secondary)
                Toggle("", isOn: $watermark.enabled).labelsHidden()
                if watermark.enabled {
                    Button {
                        showWatermarkSettings = true
                    } label: {
                        Text("设置")
                            .font(.subheadline)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 5)
                            .background(Color.white.opacity(0.12), in: Capsule())
                            .foregroundStyle(.primary)
                    }
                }
                Spacer()
            }
        }
        .padding(14)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
        .sheet(isPresented: $showLookPicker) {
            LookPickerView()
        }
        .sheet(isPresented: $showWatermarkSettings) {
            WatermarkSettingsView()
        }
    }
}

/// The five pro controls from the reference layout.
enum ManualKind: String, CaseIterable, Identifiable {
    case focus, wb, shutter, iso, ev
    var id: String { rawValue }
    var label: String {
        switch self {
        case .focus: return "对焦"
        case .wb: return "白平衡"
        case .shutter: return "快门速度"
        case .iso: return "感光"
        case .ev: return "曝光补偿"
        }
    }
    var icon: String {
        switch self {
        case .focus: return "focus"
        case .wb: return "circle.lefthalf.filled"
        case .shutter: return "timer"
        case .iso: return ""
        case .ev: return "plusminus.circle"
        }
    }
}

/// Camera screen in the reference pro-app layout (v0.3.0): black bars top and
/// bottom, the picture sits in a centred 3:4 window (not full-screen), focal
/// lengths in mm along the picture's lower edge, a row of five manual controls
/// and the shutter row in the bottom black zone.
struct CameraScreen: View {
    @StateObject private var camera = CameraManager()
    @EnvironmentObject var library: LookLibrary
    @State private var settings = LookSettings()
    @State private var isCapturing = false
    @State private var toast: String?
    @State private var showControls = false
    @State private var showLookPicker = false
    @State private var showImport = false
    @State private var lastShot: UIImage?
    @State private var selectedManual: ManualKind?

    private let accent = Color.mint

    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                // top black bar — wordmark only (the LUT chip that used to sit
                // top-right is gone by request)
                HStack {
                    Text("LumaCam")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                    Spacer()
                }
                .frame(height: 44)
                .padding(.horizontal, 16)

                // preview window, centred, never full-screen
                ZStack(alignment: .bottom) {
                    PreviewView(store: camera.store)

                    if !camera.isFront && camera.availableFocals.count > 1 {
                        HStack(spacing: 20) {
                            ForEach(camera.availableFocals, id: \.self) { f in
                                Button {
                                    camera.switchFocal(f)
                                } label: {
                                    VStack(spacing: 0) {
                                        Text(f.mm)
                                            .font(.system(size: 15, weight: .semibold))
                                        if camera.currentFocal == f {
                                            Text("mm").font(.system(size: 8, weight: .medium))
                                        }
                                    }
                                    .foregroundStyle(camera.currentFocal == f ? accent : .white)
                                }
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 6)
                        .background(Color.black.opacity(0.35), in: Capsule())
                        .padding(.bottom, 12)
                    }

                    if !camera.statusMessage.isEmpty {
                        VStack {
                            Text(camera.statusMessage)
                                .multilineTextAlignment(.center)
                                .font(.subheadline)
                                .padding(.horizontal, 16)
                                .padding(.vertical, 10)
                                .background(.ultraThinMaterial, in: Capsule())
                            Spacer()
                        }
                        .padding(.top, 12)
                    }
                }
                .aspectRatio(3.0 / 4.0, contentMode: .fit)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .clipped()

                if let kind = selectedManual {
                    manualSliderStrip(kind)
                }

                manualRow

                if showControls {
                    LookControls(settings: $settings)
                        .padding(.horizontal, 12)
                        .padding(.bottom, 10)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }

                bottomRow
            }

            if let toast {
                VStack {
                    Spacer()
                    Text(toast)
                        .font(.subheadline)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(.ultraThickMaterial, in: Capsule())
                        .padding(.bottom, 210)
                }
                .transition(.opacity)
            }
        }
        .background(Color.black)
        .sheet(isPresented: $showLookPicker) {
            LookPickerView()
        }
        .fullScreenCover(isPresented: $showImport) {
            ImportScreen()
        }
        .onAppear {
            settings.lutID = library.selectedID
            camera.start()
            camera.store.settings = settings
            TraceLog.mark("ui: camera screen appeared")
        }
        .onChange(of: settings) { _, new in
            camera.store.settings = new
        }
        .onChange(of: library.selectedID) { _, id in
            settings.lutID = id
        }
    }

    // MARK: - Manual controls row

    private func isAuto(_ kind: ManualKind) -> Bool {
        switch kind {
        case .focus: return camera.manual.focusAuto
        case .wb: return camera.manual.wbAuto
        case .shutter: return camera.manual.shutterAuto
        case .iso: return camera.manual.isoAuto
        case .ev: return camera.manual.evValue == 0
        }
    }

    private var manualRow: some View {
        HStack {
            ForEach(ManualKind.allCases) { kind in
                Button {
                    withAnimation(.easeInOut(duration: 0.18)) {
                        selectedManual = (selectedManual == kind) ? nil : kind
                    }
                } label: {
                    VStack(spacing: 3) {
                        ZStack(alignment: .bottomTrailing) {
                            Group {
                                if kind == .iso {
                                    Text("ISO").font(.system(size: 15, weight: .semibold))
                                } else {
                                    Image(systemName: kind.icon).font(.system(size: 19))
                                }
                            }
                            .frame(height: 22)
                            if isAuto(kind) {
                                Text("A")
                                    .font(.system(size: 9, weight: .bold))
                                    .foregroundStyle(accent)
                                    .offset(x: 8, y: 3)
                            }
                        }
                        Text(kind.label).font(.system(size: 10))
                    }
                    .foregroundStyle(selectedManual == kind ? accent : .white)
                    .frame(maxWidth: .infinity)
                }
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
    }

    @ViewBuilder
    private func manualSliderStrip(_ kind: ManualKind) -> some View {
        HStack(spacing: 12) {
            if kind != .ev {
                Button {
                    toggleAuto(kind)
                } label: {
                    Text("自动")
                        .font(.caption.weight(.semibold))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(isAuto(kind) ? accent : Color.white.opacity(0.15), in: Capsule())
                        .foregroundStyle(isAuto(kind) ? .black : .white)
                }
            }
            slider(for: kind)
                .tint(accent)
                .opacity(isAuto(kind) && kind != .ev ? 0.35 : 1)
                .disabled(isAuto(kind) && kind != .ev)
            Text(valueText(kind))
                .font(.caption.monospacedDigit())
                .foregroundStyle(.white)
                .frame(width: 58, alignment: .trailing)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(Color.white.opacity(0.07))
    }

    private func toggleAuto(_ kind: ManualKind) {
        switch kind {
        case .focus: camera.setFocus(auto: true, value: camera.manual.focusValue)
        case .wb: camera.setWhiteBalance(auto: true, kelvin: camera.manual.wbKelvin)
        case .shutter: camera.setShutter(auto: true, seconds: camera.manual.shutterSeconds)
        case .iso: camera.setISO(auto: true, value: camera.manual.isoValue)
        case .ev: break
        }
    }

    @ViewBuilder
    private func slider(for kind: ManualKind) -> some View {
        switch kind {
        case .focus:
            Slider(value: Binding(
                get: { Double(camera.manual.focusValue) },
                set: { camera.setFocus(auto: false, value: Float($0)) }), in: 0...1)
        case .wb:
            Slider(value: Binding(
                get: { Double(camera.manual.wbKelvin) },
                set: { camera.setWhiteBalance(auto: false, kelvin: Float($0)) }), in: 2300...8000)
        case .shutter:
            Slider(value: Binding(
                get: { log2(camera.manual.shutterSeconds) },
                set: { camera.setShutter(auto: false, seconds: pow(2.0, $0)) }),
                   in: log2(1.0 / 8000.0)...log2(1.0 / 30.0))
        case .iso:
            Slider(value: Binding(
                get: { Double(camera.manual.isoValue) },
                set: { camera.setISO(auto: false, value: Float($0)) }),
                   in: Double(camera.manual.isoMin)...Double(camera.manual.isoMax))
        case .ev:
            Slider(value: Binding(
                get: { Double(camera.manual.evValue) },
                set: { camera.setEV(Float($0)) }), in: -3...3)
        }
    }

    private func valueText(_ kind: ManualKind) -> String {
        switch kind {
        case .focus:
            return "\(Int(camera.manual.focusValue * 100))%"
        case .wb:
            return "\(Int(camera.manual.wbKelvin))K"
        case .shutter:
            let s = camera.manual.shutterSeconds
            if s < 1 {
                return "1/\(Int((1.0 / s).rounded()))"
            }
            return String(format: "%.1fs", s)
        case .iso:
            return "ISO \(Int(camera.manual.isoValue))"
        case .ev:
            return String(format: "%+.1f", camera.manual.evValue)
        }
    }

    // MARK: - Bottom row

    private var bottomRow: some View {
        HStack {
            Button { showImport = true } label: {
                Group {
                    if let lastShot {
                        Image(uiImage: lastShot)
                            .resizable()
                            .scaledToFill()
                    } else {
                        Image(systemName: "photo.on.rectangle")
                            .font(.system(size: 20))
                            .foregroundStyle(.white)
                    }
                }
                .frame(width: 46, height: 46)
                .clipShape(RoundedRectangle(cornerRadius: 8))
                .overlay(RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.white.opacity(0.7), lineWidth: 1.5))
            }
            .frame(maxWidth: .infinity)

            Button {
                withAnimation(.easeInOut(duration: 0.22)) { showControls.toggle() }
            } label: {
                Image(systemName: "slider.horizontal.3")
                    .font(.system(size: 20))
                    .foregroundStyle(.white)
                    .frame(width: 46, height: 46)
                    .background(Color.white.opacity(0.16), in: Circle())
            }
            .frame(maxWidth: .infinity)

            Button(action: shutter) {
                ZStack {
                    Circle().stroke(Color.white, lineWidth: 4.5)
                        .frame(width: 72, height: 72)
                    Circle().fill(isCapturing ? Color.gray : Color.white)
                        .frame(width: 60, height: 60)
                }
            }
            .disabled(isCapturing)
            .frame(maxWidth: .infinity)

            Button {
                camera.flipCamera()
            } label: {
                Image(systemName: "arrow.triangle.2.circlepath.camera")
                    .font(.system(size: 20))
                    .foregroundStyle(.white)
                    .frame(width: 46, height: 46)
                    .background(Color.white.opacity(0.16), in: Circle())
            }
            .frame(maxWidth: .infinity)

            Button {
                showLookPicker = true
            } label: {
                ZStack {
                    Circle()
                        .stroke(AngularGradient(
                            colors: [.red, .orange, .yellow, .green, .blue, .purple, .red],
                            center: .center), lineWidth: 3)
                        .frame(width: 46, height: 46)
                    Image(systemName: "camera.filters")
                        .font(.system(size: 16))
                        .foregroundStyle(.white)
                }
            }
            .frame(maxWidth: .infinity)
        }
        .padding(.horizontal, 18)
        .padding(.top, 6)
        .padding(.bottom, 16)
    }

    // MARK: - Shutter flow

    private func shutter() {
        guard !isCapturing else { return }
        isCapturing = true
        TraceLog.mark("shutter: tap")
        let current = settings
        // Start gathering watermark lines right away — location and weather
        // resolve in parallel while the photo is captured and processed.
        let wm = WatermarkStore.shared
        let wmTask: Task<[String], Never>? = wm.enabled
            ? Task { await WatermarkService.assembleLines(store: wm, params: camera.liveParams) }
            : nil
        camera.capturePhoto { data in
            if let data {
                DispatchQueue.global(qos: .userInitiated).async {
                    guard let raw = CIImage(data: data) else {
                        TraceLog.mark("shutter: photo data could not be decoded")
                        finishWithFallback(current, wmTask: wmTask)
                        return
                    }
                    TraceLog.mark("shutter: photo decoded \(Int(raw.extent.width))x\(Int(raw.extent.height))")
                    processAndSave(cappedForProcessing(orientedFromEXIF(raw)), settings: current, wmTask: wmTask)
                }
            } else {
                finishWithFallback(current, wmTask: wmTask)
            }
        }
    }

    /// If the photo pipeline fails, still deliver a graded frame from the live preview
    /// rather than dying or silently doing nothing.
    private func finishWithFallback(_ current: LookSettings, wmTask: Task<[String], Never>?) {
        TraceLog.mark("shutter: falling back to latest preview frame")
        guard let frame = camera.store.latestRaw else {
            DispatchQueue.main.async {
                isCapturing = false
                showToast("拍照失败，再试一次")
            }
            return
        }
        processAndSave(frame, settings: current, wmTask: wmTask)
    }

    private func processAndSave(_ image: CIImage, settings current: LookSettings,
                                wmTask: Task<[String], Never>?) {
        TraceLog.mark("process: begin")
        let processed = LookEngine.shared.apply(
            to: image, settings: current,
            grainSeed: CGFloat(Int.random(in: 0...100_000)))
        TraceLog.mark("process: chain built")
        // thumbnail for the bottom-left corner, rendered off a downscaled copy
        let thumbScale = 240 / max(processed.extent.width, 1)
        let thumbImage = processed.transformed(by: CGAffineTransform(scaleX: thumbScale, y: thumbScale))
        if let cg = LookEngine.shared.context.createCGImage(thumbImage, from: thumbImage.extent) {
            let thumb = UIImage(cgImage: cg)
            DispatchQueue.main.async { lastShot = thumb }
        }
        Task {
            let lines = await wmTask?.value ?? []
            PhotoSaver.save(processed, watermarkLines: lines,
                            watermarkPosition: WatermarkStore.shared.position) { ok in
                isCapturing = false
                TraceLog.mark("shutter: flow completed, saved=\(ok)")
                showToast(ok ? "已保存到相册" : "保存失败，请检查相册权限")
            }
        }
    }

    private func showToast(_ message: String) {
        toast = message
        Task {
            try? await Task.sleep(nanoseconds: 2_000_000_000)
            if toast == message { toast = nil }
        }
    }
}
