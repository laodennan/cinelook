import Foundation
import CoreImage
import UIKit

/// Keeps a downsized copy of every photo taken with the camera inside the
/// app's own sandbox, so the import screen can show "photos taken with this
/// camera" without needing photo-library read access (the app only holds
/// add-only permission; the picker covers library imports). Copies are the
/// finished, look-applied images at most 1600 px on the long side.
enum ShotsStore {
    static var directory: URL {
        let base = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = base.appendingPathComponent("LumaCamShots", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    static func recordShot(_ image: CIImage, context: CIContext) {
        let extent = image.extent
        let maxSide = max(extent.width, extent.height)
        let scale = maxSide > 1600 ? 1600 / maxSide : 1
        let scaled = scale < 1
            ? image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
            : image
        guard let cg = context.createCGImage(scaled, from: scaled.extent),
              let data = UIImage(cgImage: cg).jpegData(compressionQuality: 0.82) else {
            TraceLog.mark("shots: record FAILED (render)")
            return
        }
        let name = String(format: "shot-%lld.jpg", Int64(Date().timeIntervalSince1970 * 1000))
        do {
            try data.write(to: directory.appendingPathComponent(name), options: .atomic)
            TraceLog.mark("shots: recorded \(name)")
        } catch {
            TraceLog.mark("shots: record FAILED (\(error.localizedDescription))")
        }
        prune()
    }

    /// Newest first (zero-padded millisecond timestamps sort lexically).
    static func list() -> [URL] {
        let files = (try? FileManager.default.contentsOfDirectory(
            at: directory, includingPropertiesForKeys: nil)) ?? []
        return files
            .filter { $0.pathExtension.lowercased() == "jpg" }
            .sorted { $0.lastPathComponent > $1.lastPathComponent }
    }

    private static func prune(limit: Int = 30) {
        for url in list().dropFirst(limit) {
            try? FileManager.default.removeItem(at: url)
        }
    }
}
